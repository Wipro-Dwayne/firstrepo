package com.wipro.theLatteLounge.servlets;

import java.io.IOException;
import java.util.Calendar;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class BlogFormServlet
 */
@WebServlet("/BlogForm")
public class BlogFormServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ServletContext servletContext;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BlogFormServlet() {
        super();
    }
    
    @Override
	public void init(ServletConfig config) throws ServletException {
    	servletContext = config.getServletContext();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String category = request.getParameter("category");
		String title = request.getParameter("title");
		String author = request.getParameter("author");
		String content = request.getParameter("content");
		System.out.println("Category: " + category);
		System.out.println("Title: " + title);
		System.out.println("Author: " + author);
		System.out.println("content: " + content);
		
		servletContext.setAttribute("category", category);
		servletContext.setAttribute("title", title);
		servletContext.setAttribute("author", author);
		servletContext.setAttribute("content", content);
		servletContext.setAttribute("createdDate", Calendar.getInstance().toString());
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("views/adminHomepage.jsp");
		dispatcher.forward(request, response);
	}
}
