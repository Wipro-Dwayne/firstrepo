package com.wipro.theLatteLounge.servlets;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.wipro.theLatteLounge.beans.LoginBean;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet(
		description = "", 
		urlPatterns = { "/Login" }, 
		initParams = { 
				@WebInitParam(name = "adminUsername", value = "admin", description = ""),
				@WebInitParam(name = "adminPassword", value = "password", description = "")
		})
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Map<String, String> users;
	private ServletConfig servletConfig;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
    }

	@Override
	public void init(ServletConfig config) throws ServletException {
		servletConfig = config;
		String adminUsername = servletConfig.getInitParameter("adminUsername");
		String adminPassword = servletConfig.getInitParameter("adminPassword");
		
		users = new HashMap<String, String>();
		users.put(adminUsername, adminPassword);
		users.put("Dwayne", "password");
		users.put("Penny", "password");
		users.put("Ricky", "password");
		users.put("Ivan", "password");
		users.put("Said", "password");
		users.put("Joshua", "password");
		users.put("Ashley", "password");
		users.put("Emile", "password");
		users.put("Sadeer", "password");
		users.put("Gareth", "password");
		users.put("Gurmeet", "password");
		users.put("Niveay", "password");
		users.put("Hassan", "password");
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		
		LoginBean loginBean = new LoginBean();
		loginBean.setUsername(username);
		loginBean.setPassword(password);
		HttpSession session = request.getSession();
		
		if(users.containsKey(loginBean.getUsername())) {
			String value = users.get(loginBean.getUsername());
			if(value != null) {
				if(value.equals(loginBean.getPassword())) {
					session.setAttribute("username", loginBean.getUsername());
					if(username.equals("admin")) {
						RequestDispatcher dispatcher = request.getRequestDispatcher("views/adminHomepage.jsp");
						dispatcher.forward(request, response);
					} else {
						RequestDispatcher dispatcher = request.getRequestDispatcher("views/homepage.jsp");
						dispatcher.forward(request, response);
					}
				}
			}
		} else {
			response.sendRedirect("views/login.jsp");
		}
	}
}
