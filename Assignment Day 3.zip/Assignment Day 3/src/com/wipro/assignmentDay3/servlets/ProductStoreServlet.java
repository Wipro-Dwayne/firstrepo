package com.wipro.assignmentDay3.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wipro.assignmentDay3.beans.ProductBean;
import com.wipro.assignmentDay3.interfaces.ProductService;
import com.wipro.assignmentDay3.services.ProductServiceImpl;

/**
 * Servlet implementation class ProductStoreServlet
 */
@WebServlet("/productStore")
public class ProductStoreServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ProductService productService;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProductStoreServlet() {
        super();
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init() throws ServletException {
		productService = new ProductServiceImpl();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("views/ProductForm.html");
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String prodName = request.getParameter("prodName");
		double price = -1;
		try {
			price = Double.parseDouble(request.getParameter("price"));
		} catch (NumberFormatException e) {
			e.printStackTrace();
		}
		String company = request.getParameter("company");
		ProductBean bean = new ProductBean();
		bean.setProdName(prodName);
		bean.setPrice(price);
		bean.setCompany(company);
		if(productService.createProduct(bean)) {
			System.out.println("Product Created Successfully");
		} else {
			System.out.println("Error creating Product");
		}
		RequestDispatcher dispatcher = request.getRequestDispatcher("views/GetDetails.html");
		dispatcher.forward(request, response);
	}
}
