package com.wipro.assignmentDay3.servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wipro.assignmentDay3.beans.PizzaBean;
import com.wipro.assignmentDay3.interfaces.PizzaService;
import com.wipro.assignmentDay3.services.PizzaServiceImpl;

/**
 * Servlet implementation class ListPizzaServlet
 */
@WebServlet(
        description = "", 
        urlPatterns = { "/listPizzas" }, 
        initParams = { 
                @WebInitParam(name = "url", value = "jdbc:oracle:thin:@localhost:1522:orcl", description = ""),
                @WebInitParam(name = "uname", value = "scott", description = ""),
                @WebInitParam(name = "pwd", value = "tiger", description = "")
        })
public class ListPizzaServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ServletConfig servletConfig;
	private PizzaService pizzaService;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ListPizzaServlet() {
        super();
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		servletConfig = config;
		pizzaService = new PizzaServiceImpl();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url = servletConfig.getInitParameter("url");
		String uname = servletConfig.getInitParameter("uname");
		String pwd = servletConfig.getInitParameter("pwd");
		
		List<PizzaBean> orders = pizzaService.readPizzas(url, uname, pwd);
		request.setAttribute("orders", orders);
		RequestDispatcher dispatcher = request.getRequestDispatcher("views/DisplayOrders.jsp");
		dispatcher.forward(request, response);
	}
}
