package com.wipro.assignmentDay3.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wipro.assignmentDay3.beans.PizzaBean;
import com.wipro.assignmentDay3.interfaces.PizzaService;
import com.wipro.assignmentDay3.services.PizzaServiceImpl;

/**
 * Servlet implementation class PlaceOrderServlet
 */
@WebServlet(
        description = "", 
        urlPatterns = { "/placeOrder" }, 
        initParams = { 
                @WebInitParam(name = "url", value = "jdbc:oracle:thin:@localhost:1522:orcl", description = ""),
                @WebInitParam(name = "uname", value = "scott", description = ""),
                @WebInitParam(name = "pwd", value = "tiger", description = "")
        })
public class PlaceOrderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ServletConfig servletConfig;
	private PizzaService pizzaService;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PlaceOrderServlet() {
        super();
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		servletConfig = config;
		pizzaService = new PizzaServiceImpl();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String noOfPizzasString = request.getParameter("noOfPizzas");
		String pizzaType = request.getParameter("pizzaType");
		int noOfPizzas = -1;
		try {
			noOfPizzas = Integer.parseInt(noOfPizzasString);
		} catch (NumberFormatException e) {
			e.printStackTrace();
		}
		
		System.out.println("1: " + pizzaType);
		System.out.println("2: " + noOfPizzas);
		
		if(noOfPizzas > 0 && pizzaType != null && !pizzaType.isEmpty()) {
			String url = servletConfig.getInitParameter("url");
			String uname = servletConfig.getInitParameter("uname");
			String pwd = servletConfig.getInitParameter("pwd");
			
			PizzaBean bean = new PizzaBean();
			bean.setNumberOfPizzas(noOfPizzas);
			bean.setPizzaType(pizzaType);
			
			if(pizzaService.createPizza(bean, url, uname, pwd)) {
				RequestDispatcher dispatcher = request.getRequestDispatcher("listPizzas");
				dispatcher.forward(request, response);
			} else {
				System.out.println("Unable to create Pizza");
				RequestDispatcher dispatcher = request.getRequestDispatcher("views/OrderPizza.html");
				dispatcher.forward(request, response);
			}
		} else {
			System.out.println("Unable to create Pizza. No of Pizzas must be a positive number and Type of Pizza must be selected");
			RequestDispatcher dispatcher = request.getRequestDispatcher("views/OrderPizza.html");
			dispatcher.forward(request, response);
		}
	}
}
