package com.wipro.assignmentDay3.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wipro.assignmentDay3.beans.LoginBean;
import com.wipro.assignmentDay3.interfaces.LoginService;
import com.wipro.assignmentDay3.services.LoginServiceImpl;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet(
        description = "", 
        urlPatterns = { "/login" }, 
        initParams = { 
                @WebInitParam(name = "url", value = "jdbc:oracle:thin:@localhost:1522:orcl", description = ""),
                @WebInitParam(name = "uname", value = "scott", description = ""),
                @WebInitParam(name = "pwd", value = "tiger", description = "")
        })
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private LoginService loginService = new LoginServiceImpl();
	private ServletConfig servletConfig;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
    }
    
    @Override
    public void init(ServletConfig config) throws ServletException {
        servletConfig = config;
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username = request.getParameter("username");
	    String password = request.getParameter("password");
	    
	    LoginBean loginBean = new LoginBean();
	    loginBean.setUsername(username);
	    loginBean.setPassword(password);
	    //HttpSession session = request.getSession();
	    
	    String url = servletConfig.getInitParameter("url");
		String uname = servletConfig.getInitParameter("uname");
		String pwd = servletConfig.getInitParameter("pwd");
		
	    if(username != null && !username.isEmpty() && password != null && !password.isEmpty()) {
	    	if(loginService.verifyLogin(loginBean, url, uname, pwd)) {
		    	System.out.println("Logged in Successfully");
		        //session.setAttribute("username", loginBean.getUsername());
		        RequestDispatcher dispatcher = request.getRequestDispatcher("views/OrderPizza.html");
		        dispatcher.forward(request, response);
		    } else {
		    	/*String errorString = "Incorrect Login Credentials Provided. Please Try Again.";
		    	request.setAttribute("errorString", errorString);*/
		    	System.out.println("Incorrect Login Credentials Provided. Please Try Again.");
		    	RequestDispatcher dispatcher = request.getRequestDispatcher("views/login.html");
		        dispatcher.forward(request, response);
		    }
	    } else {
	    	System.out.println("Username and Password must not be empty. Please Try Again.");
	    	RequestDispatcher dispatcher = request.getRequestDispatcher("views/login.html");
	        dispatcher.forward(request, response);
	    }
	}
}
