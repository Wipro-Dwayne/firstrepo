package com.wipro.assignmentDay3.beans;

public class ProductBean {
	
	// Variables
	
	private int prodNo;
	private String prodName;
	private double price;
	private String company;
	
	// Constructors
	
	public ProductBean() {
		
	}
	
	// Setter methods

	public void setProdNo(int prodNo) {
		this.prodNo = prodNo;
	}

	public void setProdName(String prodName) {
		this.prodName = prodName;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public void setCompany(String company) {
		this.company = company;
	}
	
	// Getter methods

	public int getProdNo() {
		return prodNo;
	}

	public String getProdName() {
		return prodName;
	}

	public double getPrice() {
		return price;
	}

	public String getCompany() {
		return company;
	}
}
