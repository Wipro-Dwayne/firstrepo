package com.wipro.assignmentDay3.beans;

public class PizzaBean {
	private int orderNo;
	private int numberOfPizzas;
	private String pizzaType;
	
	public PizzaBean() {
		
	}

	public void setOrderNo(int orderNo) {
		this.orderNo = orderNo;
	}

	public void setNumberOfPizzas(int numberOfPizzas) {
		this.numberOfPizzas = numberOfPizzas;
	}

	public void setPizzaType(String pizzaType) {
		this.pizzaType = pizzaType;
	}

	public int getOrderNo() {
		return orderNo;
	}

	public int getNumberOfPizzas() {
		return numberOfPizzas;
	}

	public String getPizzaType() {
		return pizzaType;
	}	
}
