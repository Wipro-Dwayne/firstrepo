package com.wipro.assignmentDay3.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.wipro.assignmentDay3.beans.ProductBean;
import com.wipro.assignmentDay3.interfaces.ProductDAO;
import com.wipro.assignmentDay3.utils.DBUtil;

public class ProductDAOImpl implements ProductDAO {

	@Override
	public boolean createProduct(ProductBean bean) {
		try{
			Connection con = DBUtil.getConnection();
			String sql = "insert into product (prodname, price, company) values (?, ?, ?)";
			PreparedStatement pst  = con.prepareStatement(sql);
			pst.setString(1, bean.getProdName());
			pst.setDouble(2, bean.getPrice());
			pst.setString(3, bean.getCompany());
			
			int count=pst.executeUpdate();
			
			if (count==1) {
				return true;
			} else {
				return false;
			}	
		}catch(SQLException e){
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public ProductBean readProduct(int productNumber) {
		ProductBean bean = null;
		try{
			Connection con = DBUtil.getConnection();
			String sql = "select prodname, price, company from product where prodno=?";
			PreparedStatement pst  = con.prepareStatement(sql);
			pst.setInt(1, productNumber);
			
			ResultSet rs = pst.executeQuery();
			
			if(rs.next()) {
				bean = new ProductBean();
				bean.setProdNo(productNumber);
				bean.setProdName(rs.getString("prodname"));
				bean.setPrice(rs.getDouble("price"));
				bean.setCompany(rs.getString("company"));
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
		return bean;
	}
	
	@Override
	public ProductBean readProduct(String productName) {
		ProductBean bean = null;
		try{
			Connection con = DBUtil.getConnection();
			String sql = "select prodno, price, company from product where prodname=?";
			PreparedStatement pst  = con.prepareStatement(sql);
			pst.setString(1, productName);
			
			ResultSet rs = pst.executeQuery();
			
			if(rs.next()) {
				bean = new ProductBean();
				bean.setProdNo(rs.getInt("prodno"));
				bean.setProdName(productName);
				bean.setPrice(rs.getDouble("price"));
				bean.setCompany(rs.getString("company"));
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
		return bean;
	}

	@Override
	public List<ProductBean> readProducts(String company) {
		List<ProductBean> products = new ArrayList<ProductBean>();
		try{
			Connection con = DBUtil.getConnection();
			String sql = "select prodno, prodname, price from product where company=? order by prodno";
			PreparedStatement pst  = con.prepareStatement(sql);
			pst.setString(1, company);
			
			ResultSet rs = pst.executeQuery();
			
			while(rs.next()) {
				ProductBean bean = new ProductBean();
				bean.setProdNo(rs.getInt("prodno"));
				bean.setProdName(rs.getString("prodname"));
				bean.setPrice(rs.getDouble("price"));
				bean.setCompany(company);
				products.add(bean);
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
		return products;
	}

	@Override
	public boolean updateProduct(ProductBean bean) {
		try {
			Connection con = DBUtil.getConnection();
			String sql = "update product set prodname=?, price=?, company=? where prodno=?";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setString(1, bean.getProdName());
			pst.setDouble(2, bean.getPrice());
			pst.setString(3, bean.getCompany());
			pst.setInt(4, bean.getProdNo());
			
			int count=pst.executeUpdate();
			
			if (count==1){
				return true;
			} else {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean deleteProduct(int productNumber) {
		try {
			Connection con = DBUtil.getConnection();
			String sql = "delete from product where prodno=?";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setInt(1, productNumber);
					
			int count=pst.executeUpdate();
			
			if (count==1)
				return true;
			else
				return false;
			
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
}
