package com.wipro.assignmentDay3.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.wipro.assignmentDay3.beans.PizzaBean;
import com.wipro.assignmentDay3.interfaces.PizzaDAO;
import com.wipro.assignmentDay3.utils.DBUtil;
import com.wipro.assignmentDay3.utils.DBUtil2;

public class PizzaDAOImpl implements PizzaDAO {

	@Override
	public boolean createPizza(PizzaBean bean, String url, String uname,String pwd) {
		try{
			Connection con = DBUtil2.getConnection(url, uname, pwd);
			String sql = "insert into order_pizza (pizza_type, no_of_pizzas) values (?, ?)";
			PreparedStatement pst  = con.prepareStatement(sql);
			pst.setString(1, bean.getPizzaType());
			pst.setInt(2, bean.getNumberOfPizzas());
			
			int count=pst.executeUpdate();
			
			if (count==1) {
				return true;
			} else {
				return false;
			}	
		}catch(SQLException e){
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public PizzaBean readPizza(int orderNo, String url, String uname, String pwd) {
		PizzaBean bean = null;
		try{
			Connection con = DBUtil2.getConnection(url, uname, pwd);
			String sql = "select pizza_type, no_of_pizzas from order_pizza where order_no=?";
			PreparedStatement pst  = con.prepareStatement(sql);
			pst.setInt(1, orderNo);
			
			ResultSet rs = pst.executeQuery();
			
			if(rs.next()) {
				bean = new PizzaBean();
				bean.setOrderNo(orderNo);
				bean.setPizzaType(rs.getString("pizza_type"));
				bean.setNumberOfPizzas(rs.getInt("no_of_pizzas"));
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
		return bean;
	}

	@Override
	public List<PizzaBean> readPizzas(String url, String uname, String pwd) {
		List<PizzaBean> products = new ArrayList<PizzaBean>();
		try{
			Connection con = DBUtil2.getConnection(url, uname, pwd);
			String sql = "select order_no, pizza_type, no_of_pizzas from order_pizza order by order_no";
			PreparedStatement pst  = con.prepareStatement(sql);
			
			ResultSet rs = pst.executeQuery();
			
			while(rs.next()) {
				PizzaBean bean = new PizzaBean();
				bean.setOrderNo(rs.getInt("order_no"));
				bean.setPizzaType(rs.getString("pizza_type"));
				bean.setNumberOfPizzas(rs.getInt("no_of_pizzas"));
				products.add(bean);
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
		
		System.out.println("TEST: " + products.size());
		return products;
	}

	@Override
	public boolean updatePizza(PizzaBean bean, String url, String uname, String pwd) {
		try {
			Connection con = DBUtil2.getConnection(url, uname, pwd);
			String sql = "update order_pizza set pizza_type=?, no_of_pizzas=? where order_no=?";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setString(1, bean.getPizzaType());
			pst.setDouble(2, bean.getNumberOfPizzas());
			pst.setInt(3, bean.getOrderNo());
			
			int count=pst.executeUpdate();
			
			if (count==1){
				return true;
			} else {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean deletePizza(int orderNo, String url, String uname, String pwd) {
		try {
			Connection con = DBUtil.getConnection();
			String sql = "delete from order_pizza where order_no=?";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setInt(1, orderNo);
					
			int count=pst.executeUpdate();
			
			if (count==1)
				return true;
			else
				return false;
			
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
}
