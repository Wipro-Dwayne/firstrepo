package com.wipro.assignmentDay3.services;

import java.util.List;

import com.wipro.assignmentDay3.beans.PizzaBean;
import com.wipro.assignmentDay3.daos.PizzaDAOImpl;
import com.wipro.assignmentDay3.interfaces.PizzaDAO;
import com.wipro.assignmentDay3.interfaces.PizzaService;

public class PizzaServiceImpl implements PizzaService {
	private PizzaDAO pizzaDAO = new PizzaDAOImpl();

	@Override
	public boolean createPizza(PizzaBean bean, String url, String uname, String pwd) {
		return pizzaDAO.createPizza(bean, url, uname, pwd);
	}

	@Override
	public PizzaBean readPizza(int orderNo, String url, String uname, String pwd) {
		return pizzaDAO.readPizza(orderNo, url, uname, pwd);
	}
	
	@Override
	public List<PizzaBean> readPizzas(String url, String uname, String pwd) {
		return pizzaDAO.readPizzas(url, uname, pwd);
	}

	@Override
	public boolean updatePizza(PizzaBean bean, String url, String uname, String pwd) {
		return pizzaDAO.updatePizza(bean, url, uname, pwd);
	}

	@Override
	public boolean deletePizza(int orderNo, String url, String uname, String pwd) {
		return pizzaDAO.deletePizza(orderNo, url, uname, pwd);
	}
}
