package com.wipro.assignmentDay3.services;

import com.wipro.assignmentDay3.beans.LoginBean;
import com.wipro.assignmentDay3.interfaces.LoginService;
import com.wipro.assignmentDay3.daos.LoginDAOImpl;
import com.wipro.assignmentDay3.interfaces.LoginDAO;

public class LoginServiceImpl implements LoginService {
	private LoginDAO loginDAO = new LoginDAOImpl();

	@Override
	public boolean verifyLogin(LoginBean bean, String url, String uname, String pwd) {
		return loginDAO.verifyLogin(bean, url, uname, pwd);
	}

	@Override
	public boolean createLogin(LoginBean bean, String url, String uname, String pwd) {
		return loginDAO.createLogin(bean, url, uname, pwd);
	}

	@Override
	public boolean updatePassword(LoginBean bean, String url, String uname, String pwd) {
		return loginDAO.updatePassword(bean, url, uname, pwd);
	}

	@Override
	public boolean deleteLogin(String username, String url, String uname, String pwd) {
		return loginDAO.deleteLogin(username, url, uname, pwd);
	}
}
