package com.wipro.assignmentDay3.services;

import java.util.List;

import com.wipro.assignmentDay3.beans.ProductBean;
import com.wipro.assignmentDay3.daos.ProductDAOImpl;
import com.wipro.assignmentDay3.interfaces.ProductDAO;
import com.wipro.assignmentDay3.interfaces.ProductService;

public class ProductServiceImpl implements ProductService {
	private ProductDAO productDAO = new ProductDAOImpl();

	@Override
	public boolean createProduct(ProductBean bean) {
		return productDAO.createProduct(bean);
	}

	@Override
	public ProductBean readProduct(int productNumber) {
		return productDAO.readProduct(productNumber);
	}
	
	@Override
	public ProductBean readProduct(String productName) {
		return productDAO.readProduct(productName);
	}

	@Override
	public List<ProductBean> readProducts(String company) {
		return productDAO.readProducts(company);
	}

	@Override
	public boolean updateProduct(ProductBean bean) {
		return productDAO.updateProduct(bean);
	}

	@Override
	public boolean deleteProduct(int productNumber) {
		return productDAO.deleteProduct(productNumber);
	}
}
