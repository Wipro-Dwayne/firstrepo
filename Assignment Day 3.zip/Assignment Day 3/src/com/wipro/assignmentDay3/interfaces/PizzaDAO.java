package com.wipro.assignmentDay3.interfaces;

import java.util.List;

import com.wipro.assignmentDay3.beans.PizzaBean;

public interface PizzaDAO {
	public boolean createPizza(PizzaBean bean, String url, String uname, String pwd);
	public PizzaBean readPizza(int orderNo, String url, String uname, String pwd);
	public List<PizzaBean> readPizzas(String url, String uname, String pwd);
	public boolean updatePizza(PizzaBean bean, String url, String uname, String pwd);
	public boolean deletePizza(int orderNo, String url, String uname, String pwd);
}
