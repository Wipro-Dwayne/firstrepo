package com.wipro.assignmentDay3.interfaces;

import java.util.List;

import com.wipro.assignmentDay3.beans.ProductBean;

public interface ProductService {
	public boolean createProduct(ProductBean bean);
	public ProductBean readProduct(int productNumber);
	public ProductBean readProduct(String productName);
	public List<ProductBean> readProducts(String company);
	public boolean updateProduct(ProductBean bean);
	public boolean deleteProduct(int productNumber);
}
