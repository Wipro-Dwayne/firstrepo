package com.wipro.assignmentDay3.interfaces;

import com.wipro.assignmentDay3.beans.LoginBean;

public interface LoginService {
	public boolean verifyLogin(LoginBean bean, String url, String uname, String pwd);
	public boolean createLogin(LoginBean bean, String url, String uname, String pwd);
	public boolean updatePassword(LoginBean bean, String url, String uname, String pwd);
	public boolean deleteLogin(String username, String url, String uname, String pwd);
}
