package com.wipro.theLatteLounge.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.wipro.theLatteLounge.beans.RecommendationBean;
import com.wipro.theLatteLounge.interfaces.RecommendationDAO;
import com.wipro.theLatteLounge.utils.DBUtil;

public class RecommendationDAOImpl implements RecommendationDAO {

	@Override
	public boolean createRecommendation(RecommendationBean bean) {
		try {
			Connection con= DBUtil.getConnection();
			String sql="insert into member_offer values(?,?,?,?,?,?,?,?,?)";
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setInt(1, bean.getRecommendationId());
			pst.setString(2, bean.getTitle());
			pst.setString(3, bean.getPrimaryCategory());
			pst.setString(4, bean.getSecondaryCategory());
			pst.setString(5, bean.getDescription());
			pst.setDate(6, bean.getPostedDate());
			pst.setString(7, bean.getUrlLink());
			pst.setString(8, bean.getLocation());
			pst.setDouble(9, bean.getPrice());
			
			int count=pst.executeUpdate();
			
			if (count==1) {
				return true;
			} else {
				return false;
			}	
		} catch (SQLException e1) {
			e1.printStackTrace();
			return false;
		}
	}

	@Override
	public RecommendationBean readRecommendation(int recommendationId) {
		RecommendationBean bean = null;
		try{
			Connection con = DBUtil.getConnection();
			String sql = "select title, primary_category, secondary_category, description, posted_date, url_link, location, price from recommendation where recommendation_id=?";
			PreparedStatement pst  = con.prepareStatement(sql);
			pst.setInt(1, recommendationId);
			
			ResultSet rs = pst.executeQuery();
			
			if(rs.next()) {
				bean = new RecommendationBean();
				
				bean.setRecommendationId(recommendationId);
				bean.setTitle(rs.getString("title"));
				bean.setPrimaryCategory(rs.getString("primary_category"));
				bean.setSecondaryCategory(rs.getString("secondary_category"));
				bean.setDescription(rs.getString("description"));
				bean.setPostedDate(rs.getDate("posted_date"));
				bean.setUrlLink(rs.getString("url_link"));
				bean.setLocation(rs.getString("location"));
				bean.setPrice(rs.getDouble("price"));
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
		return bean;
	}

	@Override
	public List<RecommendationBean> readRecommendations() {
		List<RecommendationBean> beans = new ArrayList<RecommendationBean>();
		try{
			Connection con = DBUtil.getConnection();
			String sql = "select recommendation_id, title, primary_category, secondary_category, description, posted_date, url_link, location, price from recommendation order by recommendation_id";
			PreparedStatement pst  = con.prepareStatement(sql);
			
			ResultSet rs = pst.executeQuery();
			
			while(rs.next()) {
				RecommendationBean bean = new RecommendationBean();
				
				bean.setRecommendationId(rs.getInt("member_offer_id"));
				bean.setTitle(rs.getString("title"));
				bean.setPrimaryCategory(rs.getString("primary_category"));
				bean.setSecondaryCategory(rs.getString("secondary_category"));
				bean.setDescription(rs.getString("url_link"));
				bean.setPostedDate(rs.getDate("start_date"));
				bean.setUrlLink(rs.getString("end_date"));
				bean.setLocation(rs.getString("location"));
				bean.setPrice(rs.getDouble("price"));
				
				beans.add(bean);
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
		return beans;
	}

	@Override
	public List<RecommendationBean> readRecommendations(String title) {
		List<RecommendationBean> beans = new ArrayList<RecommendationBean>();
		try{
			Connection con = DBUtil.getConnection();
			String sql = "select recommendation_id, primary_category, secondary_category, description, posted_date, url_link, location, price from recommendation order by recommendation_id";
			PreparedStatement pst  = con.prepareStatement(sql);
			
			ResultSet rs = pst.executeQuery();
			
			while(rs.next()) {
				RecommendationBean bean = new RecommendationBean();
				
				bean.setRecommendationId(rs.getInt("member_offer_id"));
				bean.setTitle(title);
				bean.setPrimaryCategory(rs.getString("primary_category"));
				bean.setSecondaryCategory(rs.getString("secondary_category"));
				bean.setDescription(rs.getString("url_link"));
				bean.setPostedDate(rs.getDate("start_date"));
				bean.setUrlLink(rs.getString("end_date"));
				bean.setLocation(rs.getString("location"));
				bean.setPrice(rs.getDouble("price"));
				
				beans.add(bean);
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
		return beans;
	}

	@Override
	public boolean updateRecommendation(RecommendationBean bean) {
		try {
			Connection con = DBUtil.getConnection();
			String sql = "update recommendation set title=?, primary_category=?, secondary_category=?, description=?, posted_date=?, url_link=?, location=?, price=? where recommendation_id=?";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setString(1, bean.getTitle());
			pst.setString(2, bean.getPrimaryCategory());
			pst.setString(3, bean.getSecondaryCategory());
			pst.setString(4, bean.getDescription());
			pst.setDate(5, bean.getPostedDate());
			pst.setString(6, bean.getUrlLink());
			pst.setString(7, bean.getLocation());
			pst.setDouble(8, bean.getPrice());
			pst.setInt(8, bean.getRecommendationId());
			
			int count=pst.executeUpdate();
			
			if (count==1){
				return true;
			} else {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean deleteRecommendation(int recommendationId) {
		try {
			Connection con = DBUtil.getConnection();
			String sql = "delete from recommendation where recommendation_id=?";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setInt(1, recommendationId);
					
			int count=pst.executeUpdate();
			
			if (count==1)
				return true;
			else
				return false;
			
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
}
