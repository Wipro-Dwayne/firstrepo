package com.wipro.theLatteLounge.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.wipro.theLatteLounge.beans.MemberOfferBean;
import com.wipro.theLatteLounge.interfaces.MemberOfferDAO;
import com.wipro.theLatteLounge.utils.DBUtil;

public class MemberOfferDAOImpl implements MemberOfferDAO {

	@Override
	public boolean createMemberOffer(MemberOfferBean bean) {
		try {
			Connection con= DBUtil.getConnection();
			String sql="insert into member_offer values(?,?,?,?,?,?,?)";
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setInt(1, bean.getMemberOfferId());
			pst.setString(2, bean.getEstablishment());
			pst.setString(3, bean.getLogoFilePath());
			pst.setString(4, bean.getDescription());
			pst.setString(5, bean.getUrlLink());
			pst.setDate(6, bean.getStartDate());
			pst.setDate(7, bean.getEndDate());
			
			int count=pst.executeUpdate();
			
			if (count==1) {
				return true;
			} else {
				return false;
			}	
		} catch (SQLException e1) {
			e1.printStackTrace();
			return false;
		}
	}

	@Override
	public MemberOfferBean readMemberOffer(int memberOfferId) {
		MemberOfferBean bean = null;
		try{
			Connection con = DBUtil.getConnection();
			String sql = "select establishment, logo_file_path, description, url_link, start_date, end_date from member_offer where member_offer_id=?";
			PreparedStatement pst  = con.prepareStatement(sql);
			pst.setInt(1, memberOfferId);
			
			ResultSet rs = pst.executeQuery();
			
			if(rs.next()) {
				bean = new MemberOfferBean();
				
				bean.setMemberOfferId(memberOfferId);
				bean.setEstablishment(rs.getString("establishment"));
				bean.setLogoFilePath(rs.getString("logo_file_path"));
				bean.setDescription(rs.getString("description"));
				bean.setUrlLink(rs.getString("url_link"));
				bean.setStartDate(rs.getDate("start_date"));
				bean.setEndDate(rs.getDate("end_date"));
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
		return bean;
	}

	@Override
	public List<MemberOfferBean> readMemberOffers() {
		List<MemberOfferBean> beans = new ArrayList<MemberOfferBean>();
		try{
			Connection con = DBUtil.getConnection();
			String sql = "select member_offer_id, establishment, logo_file_path, description, url_link, start_date, end_date from member_offer order by member_offer_id";
			PreparedStatement pst  = con.prepareStatement(sql);
			
			ResultSet rs = pst.executeQuery();
			
			while(rs.next()) {
				MemberOfferBean bean = new MemberOfferBean();
				
				bean.setMemberOfferId(rs.getInt("member_offer_id"));
				bean.setEstablishment(rs.getString("establishment"));
				bean.setLogoFilePath(rs.getString("logo_file_path"));
				bean.setDescription(rs.getString("description"));
				bean.setUrlLink(rs.getString("url_link"));
				bean.setStartDate(rs.getDate("start_date"));
				bean.setEndDate(rs.getDate("end_date"));
				
				beans.add(bean);
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
		return beans;
	}

	@Override
	public List<MemberOfferBean> readMemberOffers(String establishment) {
		List<MemberOfferBean> beans = new ArrayList<MemberOfferBean>();
		try{
			Connection con = DBUtil.getConnection();
			String sql = "select member_offer_id, logo_file_path, description, url_link, start_date, end_date from member_offer where establishment=? order by member_offer_id";
			PreparedStatement pst  = con.prepareStatement(sql);
			pst.setString(1, establishment);
			
			ResultSet rs = pst.executeQuery();
			
			while(rs.next()) {
				MemberOfferBean bean = new MemberOfferBean();
				
				bean.setMemberOfferId(rs.getInt("member_offer_id"));
				bean.setEstablishment(establishment);
				bean.setLogoFilePath(rs.getString("logo_file_path"));
				bean.setDescription(rs.getString("description"));
				bean.setUrlLink(rs.getString("url_link"));
				bean.setStartDate(rs.getDate("start_date"));
				bean.setEndDate(rs.getDate("end_date"));
				
				beans.add(bean);
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
		return beans;
	}

	@Override
	public boolean updateMemberOffer(MemberOfferBean bean) {
		try {
			Connection con = DBUtil.getConnection();
			String sql = "update member_offer set establishment=?, logo_file_path=?, description=?, url_link=?, start_date=?, end_date=? where member_offer_id=?";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setString(1, bean.getEstablishment());
			pst.setString(2, bean.getLogoFilePath());
			pst.setString(3, bean.getDescription());
			pst.setString(4, bean.getUrlLink());
			pst.setDate(5, bean.getStartDate());
			pst.setDate(6, bean.getEndDate());
			pst.setInt(7, bean.getMemberOfferId());
			
			int count=pst.executeUpdate();
			
			if (count==1){
				return true;
			} else {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean deleteMemberOffer(int memberOfferId) {
		try {
			Connection con = DBUtil.getConnection();
			String sql = "delete from member_offer where member_offer_id=?";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setInt(1, memberOfferId);
					
			int count=pst.executeUpdate();
			
			if (count==1)
				return true;
			else
				return false;
			
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
}
