package com.wipro.theLatteLounge.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.wipro.theLatteLounge.beans.UserBean;
import com.wipro.theLatteLounge.interfaces.UserDAO;
import com.wipro.theLatteLounge.utils.DBUtil;

public class UserDAOImpl implements UserDAO {

	@Override
	public boolean userExists(String username) {
		try{
			Connection con = DBUtil.getConnection();
			String sql = "select username from user_account where username=?";
			PreparedStatement pst  = con.prepareStatement(sql);
			
			pst.setString(1, username);
			
			ResultSet rs = pst.executeQuery();
			
			if(rs.next()) {
				return true;
			} else {
				return false;
			}
		}catch(SQLException e){
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean emailExists(String email) {
		try{
			Connection con = DBUtil.getConnection();
			String sql = "select email from user_account where email=?";
			PreparedStatement pst  = con.prepareStatement(sql);
			pst.setString(1, email);
			
			ResultSet rs = pst.executeQuery();
			
			if(rs.next()) {
				return true;
			} else {
				return false;
			}
		}catch(SQLException e){
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean createUser(UserBean bean) {
		try {
			Connection con= DBUtil.getConnection();
			String sql="insert into user_account values(?,?,?,?,?,?)";
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setString(1, bean.getUsername());
			pst.setString(2, bean.getTitle());
			pst.setString(3, bean.getFirstname());
			pst.setString(4, bean.getSurname());
			pst.setDate(5, bean.getDateOfBirth());
			pst.setString(6, bean.getEmail());
			
			int count=pst.executeUpdate();
			
			if (count==1) {
				return true;
			} else {
				return false;
			}	
		} catch (SQLException e1) {
			e1.printStackTrace();
			return false;
		}
	}

	@Override
	public UserBean readUser(String username) {
		UserBean bean = null;
		try{
			Connection con = DBUtil.getConnection();
			String sql = "select title, firstname, surname, date_of_birth, email from user_account where username=?";
			PreparedStatement pst  = con.prepareStatement(sql);
			pst.setString(1, username);
			
			ResultSet rs = pst.executeQuery();
			
			if(rs.next()) {
				bean = new UserBean();
				
				bean.setUsername(username);
				bean.setTitle(rs.getString("title"));
				bean.setFirstname(rs.getString("firstname"));
				bean.setSurname(rs.getString("surname"));
				bean.setDateOfBirth(rs.getDate("date_of_birth"));
				bean.setEmail(rs.getString("email"));
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
		return bean;
	}

	@Override
	public boolean updateUser(UserBean bean) {
		try {
			Connection con = DBUtil.getConnection();
			String sql = "update user_account set title=?, firstname=?, surname=?, date_of_birth=? where username=?";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setString(1, bean.getTitle());
			pst.setString(2, bean.getFirstname());
			pst.setString(3, bean.getSurname());
			pst.setObject(4, bean.getDateOfBirth());
			pst.setString(5, bean.getUsername());
			
			int count=pst.executeUpdate();
			
			if (count==1){
				return true;
			} else {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean deleteUser(String username) {
		try {
			Connection con = DBUtil.getConnection();
			String sql = "delete from user_account where username=?";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setString(1, username);
					
			int count=pst.executeUpdate();
			
			if (count==1)
				return true;
			else
				return false;
			
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
}
