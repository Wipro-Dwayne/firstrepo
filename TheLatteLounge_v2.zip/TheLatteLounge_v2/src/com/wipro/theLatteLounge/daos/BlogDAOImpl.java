package com.wipro.theLatteLounge.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.wipro.theLatteLounge.beans.BlogBean;
import com.wipro.theLatteLounge.interfaces.BlogDAO;
import com.wipro.theLatteLounge.utils.DBUtil;

public class BlogDAOImpl implements BlogDAO {

	
	public boolean createBlog(BlogBean bean) {
		try {
			Connection con= DBUtil.getConnection();
			String sql="insert into blog (title, author, author_face_file_path, content, posted_date) values(?,?,?,?,?)";
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setString(1, bean.getTitle());
			pst.setString(2, bean.getAuthor());
			pst.setString(3, bean.getAuthorFaceFilePath());
			pst.setString(4, bean.getContent());
			pst.setDate(5, bean.getPostedDate());
			
			int count=pst.executeUpdate();
			
			if (count==1) {
				return true;
			} else {
				return false;
			}	
		} catch (SQLException e1) {
			e1.printStackTrace();
			return false;
		}
	}
	
	public boolean createBlogTag(int blogId, String tag, int index) {
		try {
			Connection con= DBUtil.getConnection();
			String sql="insert into blog_tag values(?,?,?)";
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setInt(1, blogId);
			pst.setString(2, tag);
			pst.setInt(3, index);
			
			int count=pst.executeUpdate();
			
			if (count==1) {
				return true;
			} else {
				return false;
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
			return false;
		}
	}

	public BlogBean readBlog(int blogId) {
		BlogBean bean = null;
		try{
			Connection con = DBUtil.getConnection();
			String sql = "select title, author, author_face_file_path, content, posted_date from blog where blog_id=?";
			PreparedStatement pst  = con.prepareStatement(sql);
			pst.setInt(1, blogId);
			
			ResultSet rs = pst.executeQuery();
			
			if(rs.next()) {
				bean = new BlogBean();
				
				bean.setBlogId(blogId);
				bean.setTitle(rs.getString("title"));
				bean.setAuthor(rs.getString("author"));
				bean.setAuthorFaceFilePath(rs.getString("author_face_file_path"));
				bean.setContent(rs.getString("content"));
				bean.setPostedDate(rs.getDate("posted_date"));
				
				readBlogTags(bean);
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
		return bean;
	}

	public List<BlogBean> readBlogs() {
		List<BlogBean> beans = new ArrayList<BlogBean>();
		try{
			Connection con = DBUtil.getConnection();
			String sql = "select blog_id, title, author, author_face_file_path, content, posted_date from blog order by blog_id";
			PreparedStatement pst  = con.prepareStatement(sql);
			
			ResultSet rs = pst.executeQuery();
			
			while(rs.next()) {
				BlogBean bean = new BlogBean();
				
				bean.setBlogId(rs.getInt("blog_id"));
				bean.setTitle(rs.getString("title"));
				bean.setAuthor(rs.getString("author"));
				bean.setAuthorFaceFilePath(rs.getString("author_face_file_path"));
				bean.setContent(rs.getString("content"));
				bean.setPostedDate(rs.getDate("posted_date"));
				
				readBlogTags(bean);
				beans.add(bean);
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
		return beans;
	}

	public List<BlogBean> readBlogs(String title) {
		List<BlogBean> beans = new ArrayList<BlogBean>();
		try{
			Connection con = DBUtil.getConnection();
			String sql = "select blog_id, author, author_face_file_path, content, posted_date from blog where title=? order by blog_id";
			PreparedStatement pst  = con.prepareStatement(sql);
			pst.setString(1, title);
			
			ResultSet rs = pst.executeQuery();
			
			while(rs.next()) {
				BlogBean bean = new BlogBean();
				
				bean.setBlogId(rs.getInt("blog_id"));
				bean.setTitle(title);
				bean.setAuthor(rs.getString("author"));
				bean.setAuthorFaceFilePath(rs.getString("author_face_file_path"));
				bean.setContent(rs.getString("content"));
				bean.setPostedDate(rs.getDate("posted_date"));
				
				readBlogTags(bean);
				beans.add(bean);
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
		return beans;
	}
	
	private BlogBean readBlogTags(BlogBean bean) {
		try{
			Connection con = DBUtil.getConnection();
			String sql = "select tag from blog_tag where blog_id=? order by blog_index";
			PreparedStatement pst  = con.prepareStatement(sql);
			pst.setInt(1, bean.getBlogId());
			
			ResultSet rs = pst.executeQuery();
			
			while(rs.next()) {
				bean.addTag(rs.getString("tag"));
			}
			
		}catch(SQLException e){
			e.printStackTrace();
		}
		return bean;
	}
		
	public boolean updateBlog(BlogBean bean) {
		try {
			Connection con = DBUtil.getConnection();
			String sql = "update blog set title=?, author=?, author_face_file_path=?, content=?, posted_date=? where blog_id=?";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setString(1, bean.getTitle());
			pst.setString(2, bean.getAuthor());
			pst.setString(3, bean.getAuthorFaceFilePath());
			pst.setString(4, bean.getContent());
			pst.setDate(5, bean.getPostedDate());
			pst.setInt(6, bean.getBlogId());
			
			int count=pst.executeUpdate();
			
			if (count==1){
				return true;
			} else {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public boolean updateBlogTag(int blogId, String tag, int index) {
		try {
			Connection con = DBUtil.getConnection();
			String sql = "update blog_tag set tag=? where blog_id=? and tag_index=?";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setInt(1, blogId);
			pst.setString(2, tag);
			pst.setInt(3, index+1);
			// Need to make sure that the array index is passed instead of DB index
			// Otherwise will not need to add 1 to index
			
			int count=pst.executeUpdate();
			
			if (count==1){
				return true;
			} else {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public boolean deleteBlog(int blogId) {
		try {
			Connection con = DBUtil.getConnection();
			String sql = "delete from blog where blog_id=?";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setInt(1, blogId);
					
			int count=pst.executeUpdate();
			
			if (count==1)
				return true;
			else
				return false;
			
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public boolean deleteBlogTags(int blogId) {
		try {
			Connection con = DBUtil.getConnection();
			String sql = "delete from blog_tag where blog_id=?";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setInt(1, blogId);
					
			int count=pst.executeUpdate();
			
			if (count>=1)
				return true;
			else
				return false;
			
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public boolean deleteBlogTag(int blogId, int index) {
		try {
			Connection con = DBUtil.getConnection();
			String sql = "delete from blog_tag where blog_id=? and tag_index";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setInt(1, blogId);
			pst.setInt(2, index+1);
			// Need to make sure that the array index is passed instead of DB index
			// Otherwise will not need to add 1 to index
					
			int count=pst.executeUpdate();
			
			if (count==1)
				return true;
			else
				return false;
			
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
}
