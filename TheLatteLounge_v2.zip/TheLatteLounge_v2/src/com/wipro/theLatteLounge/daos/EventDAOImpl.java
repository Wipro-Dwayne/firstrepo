package com.wipro.theLatteLounge.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.wipro.theLatteLounge.beans.EventBean;
import com.wipro.theLatteLounge.interfaces.EventDAO;
import com.wipro.theLatteLounge.utils.DBUtil;

public class EventDAOImpl implements EventDAO {

	@Override
	public boolean createEvent(EventBean bean) {
		try {
			Connection con= DBUtil.getConnection();
			String sql="insert into event values(?,?,?,?,?,?,?)";
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setInt(1, bean.getEventId());
			pst.setString(2, bean.getEventName());
			pst.setString(3, bean.getBasicInfo());
			pst.setString(4, bean.getDescription());
			pst.setString(5, bean.getLocation());
			pst.setDate(6, bean.getStartTime());
			pst.setDate(7, bean.getEndTime());
			
			int count=pst.executeUpdate();
			
			if (count==1) {
				return true;
			} else {
				return false;
			}	
		} catch (SQLException e1) {
			e1.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean createEventKeyword(int eventId, String keyword, int index) {
		try {
			Connection con= DBUtil.getConnection();
			String sql="insert into event_keyword values(?,?,?)";
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setInt(1, eventId);
			pst.setString(2, keyword);
			pst.setInt(3, index);
			
			int count=pst.executeUpdate();
			
			if (count==1) {
				return true;
			} else {
				return false;
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
			return false;
		}
	}

	@Override
	public EventBean readEvent(int eventId) {
		EventBean bean = null;
		try{
			Connection con = DBUtil.getConnection();
			String sql = "select event_name, basic_info, description, location, start_time, end_time from event where event_id=?";
			PreparedStatement pst  = con.prepareStatement(sql);
			pst.setInt(1, eventId);
			
			ResultSet rs = pst.executeQuery();
			
			if(rs.next()) {
				bean = new EventBean();
				
				bean.setEventId(eventId);
				bean.setEventName(rs.getString("event_name"));
				bean.setBasicInfo(rs.getString("basic_info"));
				bean.setDescription(rs.getString("description"));
				bean.setLocation(rs.getString("location"));
				bean.setStartTime(rs.getDate("start_time"));
				bean.setEndTime(rs.getDate("end_time"));
				
				readEventKeywords(bean);
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
		return bean;
	}

	@Override
	public List<EventBean> readEvents() {
		List<EventBean> beans = new ArrayList<EventBean>();
		try{
			Connection con = DBUtil.getConnection();
			String sql = "select event_id, event_name, basic_info, description, location, start_time, end_time from event order by event_id";
			PreparedStatement pst  = con.prepareStatement(sql);
			
			ResultSet rs = pst.executeQuery();
			
			while(rs.next()) {
				EventBean bean = new EventBean();
				
				bean.setEventId(rs.getInt("event_id"));
				bean.setEventName(rs.getString("event_name"));
				bean.setBasicInfo(rs.getString("basic_info"));
				bean.setDescription(rs.getString("description"));
				bean.setLocation(rs.getString("location"));
				bean.setStartTime(rs.getDate("start_time"));
				bean.setEndTime(rs.getDate("end_time")); 
				
				readEventKeywords(bean);
				beans.add(bean);
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
		return beans;
	}

	@Override
	public List<EventBean> readEvents(String eventName) {
		List<EventBean> beans = new ArrayList<EventBean>();
		try{
			Connection con = DBUtil.getConnection();
			String sql = "select event_id, basic_info, description, location, start_time, end_time from event where event_name=? order by event_id";
			PreparedStatement pst  = con.prepareStatement(sql);
			pst.setString(1, eventName);
			
			ResultSet rs = pst.executeQuery();
			
			while(rs.next()) {
				EventBean bean = new EventBean();
				
				bean.setEventId(rs.getInt("event_id"));
				bean.setEventName(eventName);
				bean.setBasicInfo(rs.getString("basic_info"));
				bean.setDescription(rs.getString("description"));
				bean.setLocation(rs.getString("location"));
				bean.setStartTime(rs.getDate("start_time"));
				bean.setEndTime(rs.getDate("end_time")); 
				
				readEventKeywords(bean);
				beans.add(bean);
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
		return beans;
	}
	
	private EventBean readEventKeywords(EventBean bean) {
		try{
			Connection con = DBUtil.getConnection();
			String sql = "select keyword from event_keyword where event_id=? order by event_index";
			PreparedStatement pst  = con.prepareStatement(sql);
			pst.setInt(1, bean.getEventId());
			
			ResultSet rs = pst.executeQuery();
			
			while(rs.next()) {
				bean.addKeyword(rs.getString("tag"));
			}
			
		}catch(SQLException e){
			e.printStackTrace();
		}
		return bean;
	}

	@Override
	public boolean updateEvent(EventBean bean) {
		try {
			Connection con = DBUtil.getConnection();
			String sql = "update event set event_name=?, basic_info=?, description=?, location=?, start_time=?, end_time=? where event_id=?";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setString(1, bean.getEventName());
			pst.setString(2, bean.getBasicInfo());
			pst.setString(3, bean.getDescription());
			pst.setString(4, bean.getLocation());
			pst.setDate(5, bean.getStartTime());
			pst.setDate(6, bean.getEndTime());
			pst.setInt(7, bean.getEventId());
			
			int count=pst.executeUpdate();
			
			if (count==1){
				return true;
			} else {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean updateEventKeyword(int eventId, String keyword, int index) {
		try {
			Connection con = DBUtil.getConnection();
			String sql = "update event_keyword set keyword=? where event_id=? and keyword_index=?";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setInt(1, eventId);
			pst.setString(2, keyword);
			pst.setInt(3, index+1);
			// Need to make sure that the array index is passed instead of DB index
			// Otherwise will not need to add 1 to index
			
			int count=pst.executeUpdate();
			
			if (count==1){
				return true;
			} else {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean deleteEvent(int eventId) {
		try {
			Connection con = DBUtil.getConnection();
			String sql = "delete from event where event_id=?";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setInt(1, eventId);
					
			int count=pst.executeUpdate();
			
			if (count==1)
				return true;
			else
				return false;
			
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean deleteEventKeywords(int eventId) {
		try {
			Connection con = DBUtil.getConnection();
			String sql = "delete from event_keyword where event_id=?";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setInt(1, eventId);
					
			int count=pst.executeUpdate();
			
			if (count>=1)
				return true;
			else
				return false;
			
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean deleteEventKeyword(int eventId, int index) {
		try {
			Connection con = DBUtil.getConnection();
			String sql = "delete from event_keyword where event_id=? and keyword_index";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setInt(1, eventId);
			pst.setInt(1, index+1);
			// Need to make sure that the array index is passed instead of DB index
			// Otherwise will not need to add 1 to index
					
			int count=pst.executeUpdate();
			
			if (count==1)
				return true;
			else
				return false;
			
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
}
