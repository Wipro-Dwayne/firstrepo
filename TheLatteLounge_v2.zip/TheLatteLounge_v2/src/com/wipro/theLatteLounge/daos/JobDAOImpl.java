package com.wipro.theLatteLounge.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.wipro.theLatteLounge.beans.JobBean;
import com.wipro.theLatteLounge.interfaces.JobDAO;
import com.wipro.theLatteLounge.utils.DBUtil;

public class JobDAOImpl implements JobDAO {

	@Override
	public boolean createJob(JobBean bean) {
		try {
			Connection con= DBUtil.getConnection();
			String sql="insert into job values(?,?,?,?,?,?,?,?)";
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setInt(1, bean.getJobId());
			pst.setString(2, bean.getCompany());
			pst.setString(3, bean.getTitle());
			pst.setString(4, bean.getDescription());
			pst.setString(5, bean.getLocation());
			pst.setDouble(6, bean.getSalary());
			pst.setDate(7, bean.getPostedDate());
			pst.setDate(8, bean.getClosingDate());
			
			int count=pst.executeUpdate();
			
			if (count==1) {
				return true;
			} else {
				return false;
			}	
		} catch (SQLException e1) {
			e1.printStackTrace();
			return false;
		}
	}

	@Override
	public JobBean readJob(int jobId) {
		JobBean bean = null;
		try{
			Connection con = DBUtil.getConnection();
			String sql = "select company, title, description, location, salary, posted_date, closing_date from job where job_id=?";
			PreparedStatement pst  = con.prepareStatement(sql);
			pst.setInt(1, jobId);
			
			ResultSet rs = pst.executeQuery();
			
			if(rs.next()) {
				bean = new JobBean();
				
				bean.setJobId(jobId);
				bean.setCompany(rs.getString("company"));
				bean.setTitle(rs.getString("title"));
				bean.setDescription(rs.getString("description"));
				bean.setLocation(rs.getString("location"));
				bean.setSalary(rs.getDouble("salary"));
				bean.setPostedDate(rs.getDate("posted_date"));
				bean.setClosingDate(rs.getDate("closing_date"));
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
		return bean;
	}

	@Override
	public List<JobBean> readJobs() {
		List<JobBean> beans = new ArrayList<JobBean>();
		try{
			Connection con = DBUtil.getConnection();
			String sql = "select job_id, company, title, description, location, salary, posted_date, closing_date from job order by job_id";
			PreparedStatement pst  = con.prepareStatement(sql);
			
			ResultSet rs = pst.executeQuery();
			
			while(rs.next()) {
				JobBean bean = new JobBean();
				
				bean.setJobId(rs.getInt("job_id"));
				bean.setCompany(rs.getString("company"));
				bean.setTitle(rs.getString("title"));
				bean.setDescription(rs.getString("description"));
				bean.setLocation(rs.getString("location"));
				bean.setSalary(rs.getDouble("salary"));
				bean.setPostedDate(rs.getDate("posted_date"));
				bean.setClosingDate(rs.getDate("closing_date"));
				
				beans.add(bean);
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
		return beans;
	}

	@Override
	public List<JobBean> readJobs(String jobTitle) {
		List<JobBean> beans = new ArrayList<JobBean>();
		try{
			Connection con = DBUtil.getConnection();
			String sql = "select job_id, company, title, description, location, salary, posted_date, closing_date from job where title=? order by job_id";
			PreparedStatement pst  = con.prepareStatement(sql);
			pst.setString(1, jobTitle);
			
			ResultSet rs = pst.executeQuery();
			
			while(rs.next()) {
				JobBean bean = new JobBean();
				
				bean.setJobId(rs.getInt("job_id"));
				bean.setCompany(rs.getString("company"));
				bean.setTitle(jobTitle);
				bean.setDescription(rs.getString("description"));
				bean.setLocation(rs.getString("location"));
				bean.setSalary(rs.getDouble("salary"));
				bean.setPostedDate(rs.getDate("posted_date"));
				bean.setClosingDate(rs.getDate("closing_date"));
				
				beans.add(bean);
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
		return beans;
	}

	@Override
	public boolean updateJob(JobBean bean) {
		try {
			Connection con = DBUtil.getConnection();
			String sql = "update job set company=?, title=?, description=?, location=?, salary=?, posted_date=?, closing_date=? from job where job_id=?";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setString(1, bean.getCompany());
			pst.setString(2, bean.getTitle());
			pst.setString(3, bean.getDescription());
			pst.setString(4, bean.getLocation());
			pst.setDouble(5, bean.getSalary());
			pst.setDate(6, bean.getPostedDate());
			pst.setDate(7, bean.getClosingDate());
			pst.setInt(8, bean.getJobId());
			
			int count=pst.executeUpdate();
			
			if (count==1){
				return true;
			} else {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean deleteJob(int jobId) {
		try {
			Connection con = DBUtil.getConnection();
			String sql = "delete from job where job_id=?";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setInt(1, jobId);
					
			int count=pst.executeUpdate();
			
			if (count==1)
				return true;
			else
				return false;
			
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
}
