package com.wipro.theLatteLounge.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.wipro.theLatteLounge.beans.LoginBean;
import com.wipro.theLatteLounge.interfaces.LoginDAO;
import com.wipro.theLatteLounge.utils.DBUtil;

public class LoginDAOImpl implements LoginDAO {

	@Override
	public boolean verifyLogin(LoginBean bean) {
		String username = bean.getUsername();
		try{
			Connection con = DBUtil.getConnection();
			String sql = "select username, password from login where username=?";
			PreparedStatement pst  = con.prepareStatement(sql);
			pst.setString(1, username);
			
			ResultSet rs = pst.executeQuery();
			
			if(rs.next()) {
				String password = rs.getString("password");
				if(username.equals(bean.getUsername()) && password != null && password.equals(bean.getPassword())) {
					return true;
				} else {
					return false;
				}
			} else {
				return false;
			}
		}catch(SQLException e){
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean createLogin(LoginBean bean) {
		try {
			Connection con= DBUtil.getConnection();
			String sql="insert into login values(?,?)";
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setString(1, bean.getUsername());
			pst.setString(2, bean.getPassword());
			
			int count=pst.executeUpdate();
			
			if (count==1) {
				return true;
			} else {
				return false;
			}	
		} catch (SQLException e1) {
			e1.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean updatePassword(LoginBean bean) {
		try {
			Connection con = DBUtil.getConnection();
			String sql = "update login set password=? where username=?";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setString(1, bean.getPassword());
			pst.setString(2, bean.getUsername());
			
			int count=pst.executeUpdate();
			
			if (count==1){
				return true;
			} else {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean deleteLogin(String username) {
		try {
			Connection con = DBUtil.getConnection();
			String sql = "delete from login where username=?";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setString(1, username);
					
			int count=pst.executeUpdate();
			
			if (count==1)
				return true;
			else
				return false;
			
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
}
