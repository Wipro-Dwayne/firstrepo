package com.wipro.theLatteLounge.interfaces;

import com.wipro.theLatteLounge.beans.UserBean;

public interface RegisterService {
	public boolean userExists(String username);
	public boolean emailExists(String email);
	public boolean createUser(UserBean bean);
	public UserBean readUser(String username);
	public boolean updateUser(UserBean bean);
	public boolean deleteUser(String username);
}
