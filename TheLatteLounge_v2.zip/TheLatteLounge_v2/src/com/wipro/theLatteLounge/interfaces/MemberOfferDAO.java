package com.wipro.theLatteLounge.interfaces;

import java.util.List;

import com.wipro.theLatteLounge.beans.MemberOfferBean;

public interface MemberOfferDAO {
	
	public boolean createMemberOffer(MemberOfferBean bean);
	public MemberOfferBean readMemberOffer(int memberOfferId);
	public List<MemberOfferBean> readMemberOffers();
	public List<MemberOfferBean> readMemberOffers(String establishment);
	public boolean updateMemberOffer(MemberOfferBean bean);
	public boolean deleteMemberOffer(int memberOfferId);
}
