package com.wipro.theLatteLounge.interfaces;

import java.util.List;

import com.wipro.theLatteLounge.beans.RecommendationBean;

public interface RecommendationDAO {
	
	public boolean createRecommendation(RecommendationBean bean);
	public RecommendationBean readRecommendation(int recommendationId);
	public List<RecommendationBean> readRecommendations();
	public List<RecommendationBean> readRecommendations(String title);
	public boolean updateRecommendation(RecommendationBean bean);
	public boolean deleteRecommendation(int recommendationId);
}
