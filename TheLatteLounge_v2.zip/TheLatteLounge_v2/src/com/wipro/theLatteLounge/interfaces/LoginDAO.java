package com.wipro.theLatteLounge.interfaces;

import com.wipro.theLatteLounge.beans.LoginBean;

public interface LoginDAO {
	public boolean verifyLogin(LoginBean bean);
	public boolean createLogin(LoginBean bean);
	public boolean updatePassword(LoginBean bean);
	public boolean deleteLogin(String username);
}
