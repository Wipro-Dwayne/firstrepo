package com.wipro.theLatteLounge.interfaces;

import java.util.List;

import com.wipro.theLatteLounge.beans.JobBean;

public interface JobDAO {
	
	public boolean createJob(JobBean bean);
	public JobBean readJob(int jobId);
	public List<JobBean> readJobs();
	public List<JobBean> readJobs(String jobTitle);
	public boolean updateJob(JobBean bean);
	public boolean deleteJob(int jobId);
}
