package com.wipro.theLatteLounge.interfaces;

import java.util.List;

import com.wipro.theLatteLounge.beans.EventBean;

public interface EventDAO {
	
	public boolean createEvent(EventBean bean);
	public boolean createEventKeyword(int eventId, String keyword, int index);
	public EventBean readEvent(int eventId);
	public List<EventBean> readEvents();
	public List<EventBean> readEvents(String eventName);
	public boolean updateEvent(EventBean bean);
	public boolean updateEventKeyword(int eventId, String keyword, int index);
	public boolean deleteEvent(int eventId);
	public boolean deleteEventKeywords(int eventId);
	public boolean deleteEventKeyword(int eventId, int index);
}
