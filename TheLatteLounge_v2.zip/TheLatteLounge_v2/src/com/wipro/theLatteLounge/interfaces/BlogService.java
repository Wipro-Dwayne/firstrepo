package com.wipro.theLatteLounge.interfaces;

import java.util.List;

import com.wipro.theLatteLounge.beans.BlogBean;

public interface BlogService {
	
	public boolean createBlog(BlogBean bean);
	public boolean createBlogTag(int blogId, String tag, int index);
	public BlogBean readBlog(int blogId);
	public List<BlogBean> readBlogs();
	public List<BlogBean> readBlogs(String title);
	public boolean updateBlog(BlogBean bean);
	public boolean updateBlogTag(int blogId, String tag, int index);
	public boolean deleteBlog(int blogId);
	public boolean deleteBlogTags(int blogId);
	public boolean deleteBlogTag(int blogId, int index);
}
