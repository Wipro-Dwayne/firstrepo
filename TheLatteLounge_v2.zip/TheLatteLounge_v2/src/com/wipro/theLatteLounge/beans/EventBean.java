package com.wipro.theLatteLounge.beans;

import java.util.ArrayList;
import java.sql.Date;
import java.util.List;

public class EventBean {
	
	// Variables
	
	private int eventId;
	private String eventName;
	private String basicInfo;
	private String description;
	private String location;
	private Date startTime;
	private Date endTime;
	private List<String> keywords = new ArrayList<String>();
	
	// Constructors
	
	public EventBean() {
		
	}
	
	// Setter methods
	
	public void setEventId(int eventId) {
		this.eventId = eventId;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public void setBasicInfo(String basicInfo) {
		this.basicInfo = basicInfo;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}
	
	public void addKeyword(String keyword) {
		keywords.add(keyword);
	}
	
	public void removeKeyword(int keywordIndex) {
		keywords.remove(keywordIndex);
	}

	public void setKeywords(List<String> keywords) {
		this.keywords = keywords;
	}
	
	// Getter methods
	
	public int getEventId() {
		return eventId;
	}

	public String getEventName() {
		return eventName;
	}

	public String getBasicInfo() {
		return basicInfo;
	}

	public String getDescription() {
		return description;
	}

	public String getLocation() {
		return location;
	}

	public Date getStartTime() {
		return startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public List<String> getKeywords() {
		return keywords;
	}
	
	public boolean hasKeywords() {
		return keywords.size() > 0;
	}
	
	private String listKeywords() {
		StringBuilder result = new StringBuilder();
		
		for(int i = 0; i < keywords.size(); i++) {
			result.append(keywords.get(i));
			if(keywords.size() < i-1) {
				result.append(", ");
			}
		}
		return result.toString();
	}
	
	@Override
	public String toString() {
		StringBuilder result = new StringBuilder();
	    String NEW_LINE = System.getProperty("line.separator");

	    result.append(this.getClass().getName() + " Object {" + NEW_LINE);
	    result.append(" Event ID: " + eventId + NEW_LINE);
	    result.append(" Event Name: " + eventName + NEW_LINE);
	    result.append(" Basic Info: " + basicInfo + NEW_LINE);
	    result.append(" Description: " + description + NEW_LINE);
	    result.append(" Location: " + location + NEW_LINE );
	    result.append(" Start Time: " + startTime + NEW_LINE);
	    result.append(" End Time: " + endTime + NEW_LINE);
	    result.append(" Keywords: " + listKeywords() + NEW_LINE);
	    result.append("}");

	    return result.toString();
	}
}
