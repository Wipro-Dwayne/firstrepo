package com.wipro.theLatteLounge.beans;

import java.sql.Date;

public class MemberOfferBean {
	private int memberOfferId;
	private String establishment;
	private String logoFilePath;
	private String description;
	private String urlLink;
	private Date startDate;
	private Date endDate;
	
	public MemberOfferBean() {
		
	}
	
	public void setMemberOfferId(int memberOfferId) {
		this.memberOfferId = memberOfferId;
	}

	public void setEstablishment(String establishment) {
		this.establishment = establishment;
	}

	public void setLogoFilePath(String logoFilePath) {
		this.logoFilePath = logoFilePath;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setUrlLink(String urlLink) {
		this.urlLink = urlLink;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	
	public int getMemberOfferId() {
		return memberOfferId;
	}

	public String getEstablishment() {
		return establishment;
	}

	public String getLogoFilePath() {
		return logoFilePath;
	}

	public String getDescription() {
		return description;
	}

	public String getUrlLink() {
		return urlLink;
	}

	public Date getStartDate() {
		return startDate;
	}

	public Date getEndDate() {
		return endDate;
	}
	
	@Override
	public String toString() {
		StringBuilder result = new StringBuilder();
	    String NEW_LINE = System.getProperty("line.separator");

	    result.append(this.getClass().getName() + " Object {" + NEW_LINE);
	    result.append(" Member Offer ID: " + memberOfferId + NEW_LINE);
	    result.append(" Establishment: " + establishment + NEW_LINE);
	    result.append(" Logo File Path: " + logoFilePath + NEW_LINE);
	    result.append(" Description: " + description + NEW_LINE);
	    result.append(" URL Link: " + urlLink + NEW_LINE );
	    result.append(" Start Date: " + startDate + NEW_LINE);
	    result.append(" End Date: " + endDate + NEW_LINE);
	    result.append("}");

	    return result.toString();
	}
}
