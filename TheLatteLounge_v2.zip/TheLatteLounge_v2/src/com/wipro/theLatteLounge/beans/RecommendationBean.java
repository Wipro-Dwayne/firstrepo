package com.wipro.theLatteLounge.beans;

import java.sql.Date;

public class RecommendationBean {
	private int recommendationId;
	private String title;
	private String primaryCategory;
	private String secondaryCategory;
	private String description;
	private Date postedDate;
	private String urlLink;
	private String location;
	private double price;
	
	public RecommendationBean() {
		
	}

	public void setRecommendationId(int recommendationId) {
		this.recommendationId = recommendationId;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setPrimaryCategory(String primaryCategory) {
		this.primaryCategory = primaryCategory;
	}

	public void setSecondaryCategory(String secondaryCategory) {
		this.secondaryCategory = secondaryCategory;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setPostedDate(Date postedDate) {
		this.postedDate = postedDate;
	}

	public void setUrlLink(String urlLink) {
		this.urlLink = urlLink;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	
	public int getRecommendationId() {
		return recommendationId;
	}

	public String getTitle() {
		return title;
	}

	public String getPrimaryCategory() {
		return primaryCategory;
	}

	public String getSecondaryCategory() {
		return secondaryCategory;
	}

	public String getDescription() {
		return description;
	}

	public Date getPostedDate() {
		return postedDate;
	}

	public String getUrlLink() {
		return urlLink;
	}

	public String getLocation() {
		return location;
	}

	public double getPrice() {
		return price;
	}
	
	@Override
	public String toString() {
		StringBuilder result = new StringBuilder();
	    String NEW_LINE = System.getProperty("line.separator");

	    result.append(this.getClass().getName() + " Object {" + NEW_LINE);
	    result.append(" Recommendation ID: " + recommendationId + NEW_LINE);
	    result.append(" Title: " + title + NEW_LINE);
	    result.append(" Primary Category: " + primaryCategory + NEW_LINE);
	    result.append(" Secondary Category: " + secondaryCategory + NEW_LINE );
	    result.append(" Description: " + description + NEW_LINE);
	    result.append(" Posted Date: " + postedDate + NEW_LINE);
	    result.append(" URL Link: " + urlLink + NEW_LINE);
	    result.append(" Location: " + location + NEW_LINE );
	    result.append(" Price: " + price + NEW_LINE);
	    result.append("}");

	    return result.toString();
	}
}
