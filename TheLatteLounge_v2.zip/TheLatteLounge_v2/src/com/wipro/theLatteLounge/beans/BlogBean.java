package com.wipro.theLatteLounge.beans;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

public class BlogBean {
	
	// Variables
	
	private int blogId;
	private String title;
	private String author;
	private String authorFaceFilePath;
	private String content;
	private Date postedDate;
	private List<String> tags = new ArrayList<String>();
	
	// Constructors
	
	public BlogBean() {
		
	}
	
	// Setter methods

	public void setBlogId(int blogId) {
		this.blogId = blogId;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public void setAuthorFaceFilePath(String authorFaceFilePath) {
		this.authorFaceFilePath = authorFaceFilePath;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public void setPostedDate(Date postedDate) {
		this.postedDate = postedDate;
	}
	
	public void addTag(String tag) {
		tags.add(tag);
	}
	
	public void removeTag(int tagIndex) {
		tags.remove(tagIndex);
	}

	public void setTags(ArrayList<String> tags) {
		this.tags = tags;
	}
	
	// Getter methods

	public int getBlogId() {
		return blogId; 
	}
	
	public String getTitle() {
		return title;
	}

	public String getAuthor() {
		return author;
	}

	public String getAuthorFaceFilePath() {
		return authorFaceFilePath;
	}

	public String getContent() {
		return content;
	}

	public Date getPostedDate() {
		return postedDate;
	}

	public List<String> getTags() {
		return tags;
	}
	
	public boolean hasTags() {
		return tags.size() > 0;
	}
	
	private String listTags() {
		StringBuilder result = new StringBuilder();
		
		for(int i = 0; i < tags.size(); i++) {
			result.append(tags.get(i));
			if(tags.size() < i-1) {
				result.append(", ");
			}
		}
		return result.toString();
	}
	
	@Override
	public String toString() {
		StringBuilder result = new StringBuilder();
	    String NEW_LINE = System.getProperty("line.separator");

	    result.append(this.getClass().getName() + " Object {" + NEW_LINE);
	    result.append(" Blog ID: " + blogId + NEW_LINE);
	    result.append(" Title: " + title + NEW_LINE);
	    result.append(" Author: " + author + NEW_LINE);
	    result.append(" Author Face File Path: " + authorFaceFilePath + NEW_LINE );
	    result.append(" Content: " + content + NEW_LINE);
	    result.append(" Post Date: " + postedDate + NEW_LINE);
	    result.append(" Tags: " + listTags() + NEW_LINE );
	    result.append("}");

	    return result.toString();
	}
}
