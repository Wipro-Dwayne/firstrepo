package com.wipro.theLatteLounge.beans;

import java.sql.Date;

public class UserBean {
	
	// Variables

	private String username;
	private String title;
	private String firstname;
	private String Surname;
	private Date dateOfBirth;
	private String email;
	
	// Constructors
	
	public UserBean() {
		
	}
	
	// Setter methods
	
	public void setTitle(String title) {
		this.title = title;	
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public void setSurname(String surname) {
		Surname = surname;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setUsername(String username) {
		this.username = username;
	}
	
	// Getter methods
	
	public String getTitle() {
		return title;
	}

	public String getFirstname() {
		return firstname;
	}

	public String getSurname() {
		return Surname;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public String getEmail() {
		return email;
	}

	public String getUsername() {
		return username;
	}
}
