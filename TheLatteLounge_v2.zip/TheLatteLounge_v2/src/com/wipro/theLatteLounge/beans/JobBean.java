package com.wipro.theLatteLounge.beans;

import java.sql.Date;

public class JobBean {
	private int jobId;
	private String company;
	private String title;
	private String description;
	private String location;
	private double salary;
	private Date postedDate;
	private Date closingDate;
	
	public JobBean() {
		
	}
	
	public void setJobId(int jobId) {
		this.jobId = jobId;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	public void setPostedDate(Date postedDate) {
		this.postedDate = postedDate;
	}
	
	public void setClosingDate(Date closingDate) {
		this.closingDate = closingDate;
	}
	
	public int getJobId() {
		return jobId;
	}

	public String getCompany() {
		return company;
	}

	public String getTitle() {
		return title;
	}

	public String getDescription() {
		return description;
	}

	public String getLocation() {
		return location;
	}

	public double getSalary() {
		return salary;
	}

	public Date getPostedDate() {
		return postedDate;
	}

	public Date getClosingDate() {
		return closingDate;
	}
	
	@Override
	public String toString() {
		StringBuilder result = new StringBuilder();
	    String NEW_LINE = System.getProperty("line.separator");

	    result.append(this.getClass().getName() + " Object {" + NEW_LINE);
	    result.append(" Job ID: " + jobId + NEW_LINE);
	    result.append(" Company: " + company + NEW_LINE);
	    result.append(" Title: " + title + NEW_LINE);
	    result.append(" Description: " + description + NEW_LINE);
	    result.append(" Location: " + location + NEW_LINE );
	    result.append(" Salary: " + salary + NEW_LINE);
	    result.append(" Posted Date: " + postedDate + NEW_LINE);
	    result.append(" Closing Date: " + closingDate + NEW_LINE);
	    result.append("}");

	    return result.toString();
	}
}
