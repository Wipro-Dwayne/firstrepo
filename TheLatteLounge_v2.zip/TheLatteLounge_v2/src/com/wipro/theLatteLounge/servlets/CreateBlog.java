package com.wipro.theLatteLounge.servlets;

import java.io.IOException;
import java.sql.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.wipro.theLatteLounge.beans.BlogBean;
import com.wipro.theLatteLounge.interfaces.BlogService;
import com.wipro.theLatteLounge.services.BlogServiceImpl;

/**
 * Servlet implementation class CreateBlog
 */
@WebServlet("/create-blog")
public class CreateBlog extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private BlogService blogService;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CreateBlog() {
        super();
    }

	/**
	 * @see Servlet#init()
	 */
	public void init() throws ServletException {
		blogService = new BlogServiceImpl();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		request.setAttribute("username", (String) session.getAttribute("username"));
		
        RequestDispatcher dispatcher = request.getRequestDispatcher("views/create-blog.jsp");
        dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		request.setAttribute("username", (String) session.getAttribute("username"));
		
		String title = request.getParameter("title");
		String author = request.getParameter("author");
		String authorFaceFilePath = request.getParameter("authorFaceFilePath");
		java.util.Date utilDate = new java.util.Date();
		Date postedDate = new Date(utilDate.getTime());
		String content = request.getParameter("content");
		
		BlogBean bean = new BlogBean();
		bean.setTitle(title);
		bean.setAuthor(author);
		bean.setAuthorFaceFilePath(authorFaceFilePath);
		bean.setContent(content);
		bean.setPostedDate(postedDate);
		
		if(blogService.createBlog(bean)) {
			RequestDispatcher dispatcher = request.getRequestDispatcher("/list-blogs");
            dispatcher.forward(request, response);
		} else {
			request.setAttribute("errorString", "There was an error updating Blog. Please Try Again");
			RequestDispatcher dispatcher = request.getRequestDispatcher("views/create-blog.jsp");
            dispatcher.forward(request, response);
		}
	}
}
