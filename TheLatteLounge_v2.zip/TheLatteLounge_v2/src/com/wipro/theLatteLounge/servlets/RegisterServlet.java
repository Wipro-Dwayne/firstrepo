package com.wipro.theLatteLounge.servlets;

import java.io.IOException;
import java.sql.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wipro.theLatteLounge.beans.LoginBean;
import com.wipro.theLatteLounge.beans.UserBean;
import com.wipro.theLatteLounge.interfaces.LoginService;
import com.wipro.theLatteLounge.interfaces.RegisterService;
import com.wipro.theLatteLounge.services.LoginServiceImpl;
import com.wipro.theLatteLounge.services.RegisterServiceImpl;
import com.wipro.theLatteLounge.utils.DateUtil;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private RegisterService registerService;
	private LoginService loginService;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterServlet() {
        super();
    }
    
    @Override
    public void init() throws ServletException {
        registerService = new RegisterServiceImpl();
        loginService = new LoginServiceImpl();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("views/register.jsp");
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username = request.getParameter("username");
		
		if(registerService.userExists(username)) {
			RequestDispatcher dispatcher = request.getRequestDispatcher("views/register.jsp");
			request.setAttribute("errorString", "Username already exists. Please choose another Username");
            dispatcher.forward(request, response);
		} else {
			String email = request.getParameter("email");
			if(registerService.emailExists(email)) {
				RequestDispatcher dispatcher = request.getRequestDispatcher("views/register.jsp");
				request.setAttribute("errorString", "Email already exists. Please choose another Username");
	            dispatcher.forward(request, response);
			} else {
				String title = request.getParameter("title");
				String firstname = request.getParameter("firstname");
				String surname = request.getParameter("surname");
				Date dateOfBirth = DateUtil.convertDateToString(request.getParameter("dateOfBirth"));
				
				String password = request.getParameter("password");
				
				LoginBean loginBean = new LoginBean();
				UserBean userBean = new UserBean();
				
				loginBean.setUsername(username);
				loginBean.setPassword(password);
				
				userBean.setUsername(username);
				userBean.setTitle(title);
				userBean.setFirstname(firstname);
				userBean.setSurname(surname);
				userBean.setDateOfBirth(dateOfBirth);
				userBean.setEmail(email);
				
				if(registerService.createUser(userBean) && loginService.createLogin(loginBean)) {
					request.setAttribute("username", username);
					request.setAttribute("email", email);
					RequestDispatcher dispatcher = request.getRequestDispatcher("views/registered.jsp");
		            dispatcher.forward(request, response);
				} else {
					RequestDispatcher dispatcher = request.getRequestDispatcher("views/register.jsp");
					request.setAttribute("errorString", "There was an error creating user account. Please Try Again");
		            dispatcher.forward(request, response);
				}
			}	
		}
	}
}
