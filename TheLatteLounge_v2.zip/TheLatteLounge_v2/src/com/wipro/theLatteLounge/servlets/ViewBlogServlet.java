package com.wipro.theLatteLounge.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.wipro.theLatteLounge.beans.BlogBean;
import com.wipro.theLatteLounge.interfaces.BlogService;
import com.wipro.theLatteLounge.services.BlogServiceImpl;

/**
 * Servlet implementation class ViewBlogServlet
 */
@WebServlet("/view-blog")
public class ViewBlogServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private BlogService blogService;	
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ViewBlogServlet() {
        super();
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init() throws ServletException {
		blogService = new BlogServiceImpl();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		String blogId = request.getParameter("blogId");
		BlogBean bean = blogService.readBlog(Integer.parseInt(blogId));
		request.setAttribute("blog", bean);
		request.setAttribute("postedDate", bean.getPostedDate().toString());
		request.setAttribute("username", (String) session.getAttribute("username"));
        RequestDispatcher dispatcher = request.getRequestDispatcher("views/view-blog.jsp");
        dispatcher.forward(request, response);
	}
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
