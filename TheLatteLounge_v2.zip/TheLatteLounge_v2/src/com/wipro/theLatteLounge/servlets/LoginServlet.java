package com.wipro.theLatteLounge.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.wipro.theLatteLounge.beans.LoginBean;
import com.wipro.theLatteLounge.interfaces.LoginService;
import com.wipro.theLatteLounge.services.LoginServiceImpl;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet(
        description = "", 
        urlPatterns = { "/login" }, 
        initParams = { 
                @WebInitParam(name = "adminUsername", value = "admin", description = ""),
                @WebInitParam(name = "adminPassword", value = "password", description = "")
        })
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private ServletConfig servletConfig;
    private LoginService loginService;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
    }

    @Override
    public void init(ServletConfig config) throws ServletException {
        servletConfig = config;
        String adminUsername = servletConfig.getInitParameter("adminUsername");
        String adminPassword = servletConfig.getInitParameter("adminPassword");

        loginService = new LoginServiceImpl();
        
        LoginBean adminLoginBean = new LoginBean();
        adminLoginBean.setUsername(adminUsername);
        adminLoginBean.setPassword(adminPassword);
        
        if(!loginService.verifyLogin(adminLoginBean)) {
        	loginService.createLogin(adminLoginBean);
        }
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	RequestDispatcher dispatcher = request.getRequestDispatcher("views/login.jsp");
		dispatcher.forward(request, response);
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        
        LoginBean loginBean = new LoginBean();
        loginBean.setUsername(username);
        loginBean.setPassword(password);
        HttpSession session = request.getSession();
        
        if(loginService.verifyLogin(loginBean)) {
            session.setAttribute("username", loginBean.getUsername());
            RequestDispatcher dispatcher = request.getRequestDispatcher("views/homepage.jsp");
            dispatcher.forward(request, response);
        } else {
            response.sendRedirect("views/login.jsp");
        }
    }
}
