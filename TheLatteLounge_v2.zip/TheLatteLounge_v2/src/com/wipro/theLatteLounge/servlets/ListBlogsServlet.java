package com.wipro.theLatteLounge.servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.wipro.theLatteLounge.beans.BlogBean;
import com.wipro.theLatteLounge.interfaces.BlogService;
import com.wipro.theLatteLounge.services.BlogServiceImpl;

/**
 * Servlet implementation class ListBlogsServlet
 */
@WebServlet("/list-blogs")
public class ListBlogsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private BlogService blogService;
	
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ListBlogsServlet() {
        super();
    }

	@Override
	public void init() throws ServletException {
		blogService = new BlogServiceImpl();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("TEST3");
		HttpSession session = request.getSession(false);
		request.setAttribute("username", (String) session.getAttribute("username"));
		
		List<BlogBean> theBlogs = blogService.readBlogs();
		request.setAttribute("theBlogs", theBlogs);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("views/list-blogs.jsp");
		dispatcher.forward(request, response);
	}
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
