package com.wipro.theLatteLounge.servlets;

import java.io.IOException;
import java.sql.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.wipro.theLatteLounge.beans.BlogBean;
import com.wipro.theLatteLounge.interfaces.BlogService;
import com.wipro.theLatteLounge.services.BlogServiceImpl;
import com.wipro.theLatteLounge.utils.DateUtil;

/**
 * Servlet implementation class EditBlogServlet
 */
@WebServlet("/edit-blog")
public class EditBlogServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private BlogService blogService;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditBlogServlet() {
        super();
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init() throws ServletException {
		blogService = new BlogServiceImpl();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		request.setAttribute("username", (String) session.getAttribute("username"));
		
		String blogId = request.getParameter("blogId");
		BlogBean bean = blogService.readBlog(Integer.parseInt(blogId));
		request.setAttribute("blog", bean);
		request.setAttribute("postedDate", bean.getPostedDate().toString());
		
        RequestDispatcher dispatcher = request.getRequestDispatcher("views/edit-blog.jsp");
        dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		request.setAttribute("username", (String) session.getAttribute("username"));
		
		int blogId = Integer.parseInt(request.getParameter("blogId"));
		String title = request.getParameter("title");
		String author = request.getParameter("author");
		String authorFaceFilePath = request.getParameter("authorFaceFilePath");
		Date postedDate = DateUtil.convertDateToString(request.getParameter("postedDate"));
		String content = request.getParameter("content");
		
		BlogBean bean = new BlogBean();
		bean.setBlogId(blogId);
		bean.setTitle(title);
		bean.setAuthor(author);
		bean.setAuthorFaceFilePath(authorFaceFilePath);
		bean.setContent(content);
		bean.setPostedDate(postedDate);
		
		if(blogService.updateBlog(bean)) {
			System.out.println("TEST1");
			RequestDispatcher dispatcher = request.getRequestDispatcher("list-blogs");
            dispatcher.forward(request, response);
		} else {
			System.out.println("TEST2");
			request.setAttribute("errorString", "There was an error updating Blog. Please Try Again");
			request.setAttribute("blog", bean);
			RequestDispatcher dispatcher = request.getRequestDispatcher("views/view-blog.jsp");
            dispatcher.forward(request, response);
		}
	}
}
