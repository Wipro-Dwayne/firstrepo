package com.wipro.theLatteLounge.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.wipro.theLatteLounge.interfaces.BlogService;
import com.wipro.theLatteLounge.services.BlogServiceImpl;

/**
 * Servlet implementation class DeleteBlog
 */
@WebServlet("/delete-blog")
public class DeleteBlog extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private BlogService blogService;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteBlog() {
        super();
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init() throws ServletException {
		blogService = new BlogServiceImpl();
		
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		request.setAttribute("username", (String) session.getAttribute("username"));
		
		int blogId = Integer.parseInt(request.getParameter("blogId"));
		if(blogService.deleteBlog(blogId)) {
			RequestDispatcher dispatcher = request.getRequestDispatcher("list-blogs");
			dispatcher.forward(request, response);
		} else {
			request.setAttribute("errorString", "There was an deleting updating Blog. Please Try Again");
			RequestDispatcher dispatcher = request.getRequestDispatcher("views/list-blogs.jsp");
	        dispatcher.forward(request, response);
		}
	}
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
