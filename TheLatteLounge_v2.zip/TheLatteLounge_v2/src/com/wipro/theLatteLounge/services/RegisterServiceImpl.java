package com.wipro.theLatteLounge.services;

import com.wipro.theLatteLounge.beans.UserBean;
import com.wipro.theLatteLounge.daos.UserDAOImpl;
import com.wipro.theLatteLounge.interfaces.RegisterService;
import com.wipro.theLatteLounge.interfaces.UserDAO;

public class RegisterServiceImpl implements RegisterService {
	private UserDAO userDAO = new UserDAOImpl();

	@Override
	public boolean userExists(String username) {
		return userDAO.userExists(username);
	}
	
	@Override
	public boolean emailExists(String email) {
		return userDAO.emailExists(email);
	}

	@Override
	public boolean createUser(UserBean bean) {
		return userDAO.createUser(bean);
	}

	@Override
	public UserBean readUser(String username) {
		return userDAO.readUser(username);
	}

	@Override
	public boolean updateUser(UserBean bean) {
		return userDAO.updateUser(bean);
	}

	@Override
	public boolean deleteUser(String username) {
		return userDAO.deleteUser(username);
	}
	
}
