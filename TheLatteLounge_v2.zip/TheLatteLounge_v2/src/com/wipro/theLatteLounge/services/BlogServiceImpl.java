package com.wipro.theLatteLounge.services;

import java.util.List;

import com.wipro.theLatteLounge.beans.BlogBean;
import com.wipro.theLatteLounge.daos.BlogDAOImpl;
import com.wipro.theLatteLounge.interfaces.BlogDAO;
import com.wipro.theLatteLounge.interfaces.BlogService;

public class BlogServiceImpl implements BlogService {
	
	private BlogDAO blogDAO = new BlogDAOImpl();

	@Override
	public boolean createBlog(BlogBean bean) {
		return blogDAO.createBlog(bean);
	}

	@Override
	public boolean createBlogTag(int blogId, String tag, int index) {
		return blogDAO.createBlogTag(blogId, tag, index);
	}

	@Override
	public BlogBean readBlog(int blogId) {
		return blogDAO.readBlog(blogId);
	}

	@Override
	public List<BlogBean> readBlogs() {
		return blogDAO.readBlogs();
	}

	@Override
	public List<BlogBean> readBlogs(String title) {
		return blogDAO.readBlogs(title);
	}

	@Override
	public boolean updateBlog(BlogBean bean) {
		return blogDAO.updateBlog(bean);
	}

	@Override
	public boolean updateBlogTag(int blogId, String tag, int index) {
		return blogDAO.updateBlogTag(blogId, tag, index);
	}

	@Override
	public boolean deleteBlog(int blogId) {
		return blogDAO.deleteBlog(blogId);
	}

	@Override
	public boolean deleteBlogTags(int blogId) {
		return blogDAO.deleteBlogTags(blogId);
	}

	@Override
	public boolean deleteBlogTag(int blogId, int index) {
		return blogDAO.deleteBlogTag(blogId, index);
	}
}
