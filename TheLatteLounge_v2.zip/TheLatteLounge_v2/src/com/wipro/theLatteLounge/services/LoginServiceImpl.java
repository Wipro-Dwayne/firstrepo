package com.wipro.theLatteLounge.services;

import com.wipro.theLatteLounge.beans.LoginBean;
import com.wipro.theLatteLounge.daos.LoginDAOImpl;
import com.wipro.theLatteLounge.interfaces.LoginDAO;
import com.wipro.theLatteLounge.interfaces.LoginService;

public class LoginServiceImpl implements LoginService {
	private LoginDAO loginDAO = new LoginDAOImpl();

	@Override
	public boolean verifyLogin(LoginBean bean) {
		return loginDAO.verifyLogin(bean);
	}

	@Override
	public boolean createLogin(LoginBean bean) {
		return loginDAO.createLogin(bean);
	}

	@Override
	public boolean updatePassword(LoginBean bean) {
		return loginDAO.updatePassword(bean);
	}

	@Override
	public boolean deleteLogin(String username) {
		return loginDAO.deleteLogin(username);
	}
}
