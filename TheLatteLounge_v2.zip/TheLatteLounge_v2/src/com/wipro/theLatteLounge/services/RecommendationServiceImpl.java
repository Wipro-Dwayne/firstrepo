package com.wipro.theLatteLounge.services;

import java.util.List;

import com.wipro.theLatteLounge.beans.RecommendationBean;
import com.wipro.theLatteLounge.daos.RecommendationDAOImpl;
import com.wipro.theLatteLounge.interfaces.RecommendationDAO;
import com.wipro.theLatteLounge.interfaces.RecommendationService;

public class RecommendationServiceImpl implements RecommendationService {
	private RecommendationDAO recommendationDAO = new RecommendationDAOImpl();

	@Override
	public boolean createRecommendation(RecommendationBean bean) {
		return recommendationDAO.createRecommendation(bean);
	}

	@Override
	public RecommendationBean readRecommendation(int recommendationId) {
		return recommendationDAO.readRecommendation(recommendationId);
	}

	@Override
	public List<RecommendationBean> readRecommendations() {
		return recommendationDAO.readRecommendations();
	}

	@Override
	public List<RecommendationBean> readRecommendations(String title) {
		return recommendationDAO.readRecommendations(title);
	}

	@Override
	public boolean updateRecommendation(RecommendationBean bean) {
		return recommendationDAO.updateRecommendation(bean);
	}

	@Override
	public boolean deleteRecommendation(int recommendationId) {
		return recommendationDAO.deleteRecommendation(recommendationId);
	}
}
