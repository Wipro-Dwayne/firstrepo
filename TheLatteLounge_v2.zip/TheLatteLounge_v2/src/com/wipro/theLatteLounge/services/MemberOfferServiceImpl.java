package com.wipro.theLatteLounge.services;

import java.util.List;

import com.wipro.theLatteLounge.beans.MemberOfferBean;
import com.wipro.theLatteLounge.daos.MemberOfferDAOImpl;
import com.wipro.theLatteLounge.interfaces.MemberOfferDAO;
import com.wipro.theLatteLounge.interfaces.MemberOfferService;

public class MemberOfferServiceImpl implements MemberOfferService {
	
	private MemberOfferDAO memberOfferDAO = new MemberOfferDAOImpl();

	@Override
	public boolean createMemberOffer(MemberOfferBean bean) {
		return memberOfferDAO.createMemberOffer(bean);
	}

	@Override
	public MemberOfferBean readMemberOffer(int memberOfferId) {
		return memberOfferDAO.readMemberOffer(memberOfferId);
	}

	@Override
	public List<MemberOfferBean> readMemberOffers() {
		return memberOfferDAO.readMemberOffers();
	}

	@Override
	public List<MemberOfferBean> readMemberOffers(String establishment) {
		return memberOfferDAO.readMemberOffers(establishment);
	}

	@Override
	public boolean updateMemberOffer(MemberOfferBean bean) {
		return memberOfferDAO.updateMemberOffer(bean);
	}

	@Override
	public boolean deleteMemberOffer(int memberOfferId) {
		return memberOfferDAO.deleteMemberOffer(memberOfferId);
	}
}
