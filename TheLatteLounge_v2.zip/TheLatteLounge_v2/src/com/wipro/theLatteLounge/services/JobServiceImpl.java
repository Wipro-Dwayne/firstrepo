package com.wipro.theLatteLounge.services;

import java.util.List;

import com.wipro.theLatteLounge.beans.JobBean;
import com.wipro.theLatteLounge.daos.JobDAOImpl;
import com.wipro.theLatteLounge.interfaces.JobDAO;
import com.wipro.theLatteLounge.interfaces.JobService;

public class JobServiceImpl implements JobService {
	
	private JobDAO jobDAO = new JobDAOImpl();

	@Override
	public boolean createJob(JobBean bean) {
		return jobDAO.createJob(bean);
	}

	@Override
	public JobBean readJob(int jobId) {
		return jobDAO.readJob(jobId);
	}

	@Override
	public List<JobBean> readJobs() {
		return jobDAO.readJobs();
	}

	@Override
	public List<JobBean> readJobs(String jobTitle) {
		return jobDAO.readJobs(jobTitle);
	}

	@Override
	public boolean updateJob(JobBean bean) {
		return jobDAO.updateJob(bean);
	}

	@Override
	public boolean deleteJob(int jobId) {
		return jobDAO.deleteJob(jobId);
	}
}
