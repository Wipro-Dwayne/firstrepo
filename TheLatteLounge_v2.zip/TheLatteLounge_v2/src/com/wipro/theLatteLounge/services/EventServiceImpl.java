package com.wipro.theLatteLounge.services;

import java.util.List;

import com.wipro.theLatteLounge.beans.EventBean;
import com.wipro.theLatteLounge.daos.EventDAOImpl;
import com.wipro.theLatteLounge.interfaces.EventDAO;
import com.wipro.theLatteLounge.interfaces.EventService;

public class EventServiceImpl implements EventService {
	
	private EventDAO eventDAO = new EventDAOImpl();

	@Override
	public boolean createEvent(EventBean bean) {
		return eventDAO.createEvent(bean);
	}

	@Override
	public boolean createEventKeyword(int eventId, String keyword, int index) {
		return eventDAO.createEventKeyword(eventId, keyword, index);
	}

	@Override
	public EventBean readEvent(int eventId) {
		return eventDAO.readEvent(eventId);
	}

	@Override
	public List<EventBean> readEvents() {
		return eventDAO.readEvents();
	}

	@Override
	public List<EventBean> readEvents(String eventName) {
		return eventDAO.readEvents(eventName);
	}

	@Override
	public boolean updateEvent(EventBean bean) {
		return eventDAO.updateEvent(bean);
	}

	@Override
	public boolean updateEventKeyword(int eventId, String keyword, int index) {
		return eventDAO.updateEventKeyword(eventId, keyword, index);
	}

	@Override
	public boolean deleteEvent(int eventId) {
		return eventDAO.deleteEvent(eventId);
	}

	@Override
	public boolean deleteEventKeywords(int eventId) {
		return eventDAO.deleteEventKeywords(eventId);
	}

	@Override
	public boolean deleteEventKeyword(int eventId, int index) {
		return eventDAO.deleteEventKeyword(eventId, index);
	}

}
