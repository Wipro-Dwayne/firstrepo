package com.wipro.theLatteLounge.utils;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class DateUtil {
	
	public static Date convertDateToString(String dateString) {
		SimpleDateFormat dateTimeFormatter = new SimpleDateFormat("dd-mm-yyyy");
		
		java.util.Date date = null;
		try {
			date = dateTimeFormatter.parse(dateString);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		Date newDate = new java.sql.Date(date.getTime());
		return newDate;
	}
}
