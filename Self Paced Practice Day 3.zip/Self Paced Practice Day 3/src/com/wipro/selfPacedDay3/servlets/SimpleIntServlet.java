package com.wipro.selfPacedDay3.servlets;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SimpleIntServlet
 */
@WebServlet("/simpleInt")
public class SimpleIntServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SimpleIntServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String principalAmountString = request.getParameter("principalAmount");
		String noOfYearsString = request.getParameter("noOfYears");
		String rateOfInterestString = request.getParameter("rateOfInterest");
		if(principalAmountString != null && !principalAmountString.isEmpty() && noOfYearsString != null && !noOfYearsString.isEmpty() && rateOfInterestString != null && !rateOfInterestString.isEmpty()) {
			double principalAmount;
			int noOfYears;
			double rateOfInterest;
			try {
				principalAmount = Double.parseDouble(principalAmountString);
				noOfYears = Integer.parseInt(noOfYearsString);
				rateOfInterest = Double.parseDouble(rateOfInterestString);
				double result = principalAmount;
				for(int i = 0; i < noOfYears; i++) {
					double interest = result * (rateOfInterest / 100);
					System.out.println(interest);
					result = result + interest;
					System.out.println(i + " : " + result);
				}
				result = round(result, 2);
				request.setAttribute("result", result);
				request.setAttribute("principalAmount", principalAmount);
				request.setAttribute("noOfYears", noOfYears);
				request.setAttribute("rateOfInterest", rateOfInterest);
				RequestDispatcher dispatcher = request.getRequestDispatcher("views/Interest-result.jsp");
				dispatcher.forward(request,  response);
			} catch (NumberFormatException e){
				e.printStackTrace();
			}
		} else {
			RequestDispatcher dispatcher = request.getRequestDispatcher("views/Add.html");
			dispatcher.forward(request,  response);
		}
	}
	
	private static double round(double value, int places) {
	    if(places < 0) {
	    	throw new IllegalArgumentException();
	    } else {
	    	BigDecimal bd = new BigDecimal(value);
		    bd = bd.setScale(places, RoundingMode.HALF_UP);
		    return bd.doubleValue();
	    }
	}
}
