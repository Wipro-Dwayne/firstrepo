package com.wipro.selfPacedDay3.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AdditionServlet
 */
@WebServlet("/addition")
public class AdditionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdditionServlet() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("views/addition.html");
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String number1String = request.getParameter("number1");
		String number2String = request.getParameter("number2");
		if(number1String != null && !number1String.isEmpty() && number2String != null && !number2String.isEmpty()) {
			double number1;
			double number2;
			try {
				number1 = Double.parseDouble(number1String);
				number2 = Double.parseDouble(number2String);
				double result = number1 + number2;
				String message = number1 + " add " + number2 + " equals " + result;
				request.setAttribute("message", message);
				RequestDispatcher dispatcher = request.getRequestDispatcher("views/Arithmetic-result.jsp");
				dispatcher.forward(request,  response);
			} catch (NumberFormatException e){
				e.printStackTrace();
			}
		}else {
			RequestDispatcher dispatcher = request.getRequestDispatcher("views/addition.html");
			dispatcher.forward(request,  response);
		}
	}
}
