package com.wipro.selfPacedDay3.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wipro.selfPacedDay3.beans.EmployeeBean;
import com.wipro.selfPacedDay3.interfaces.EmployeeService;
import com.wipro.selfPacedDay3.services.EmployeeServiceImpl;

/**
 * Servlet implementation class EmployeeServlet
 */
@WebServlet("/employee")
public class EmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private EmployeeService employeeService;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmployeeServlet() {
        super();
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init() throws ServletException {
		employeeService = new EmployeeServiceImpl();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int employeeNumber = -1;
		try {
			employeeNumber = Integer.parseInt(request.getParameter("employeeNumber"));
		} catch (NumberFormatException e){
			e.printStackTrace();
		}
		EmployeeBean bean = employeeService.readEmployee(employeeNumber);
		if(bean != null) {
			System.out.println("Retrieved Bean: " + bean.getEmployeeNumber());
			request.setAttribute("employee", bean);
			RequestDispatcher dispatcher = request.getRequestDispatcher("views/employeeView.jsp");
			dispatcher.forward(request, response);
		} else {
			RequestDispatcher dispatcher = request.getRequestDispatcher("views/employee.html");
			dispatcher.forward(request, response);
		}
	}
}
