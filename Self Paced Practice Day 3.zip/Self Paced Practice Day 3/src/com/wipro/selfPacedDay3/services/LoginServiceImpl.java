package com.wipro.selfPacedDay3.services;

import com.wipro.selfPacedDay3.beans.LoginBean;
import com.wipro.selfPacedDay3.interfaces.LoginService;
import com.wipro.selfPacedDay3.daos.LoginDAOImpl;
import com.wipro.selfPacedDay3.interfaces.LoginDAO;

public class LoginServiceImpl implements LoginService {
	private LoginDAO loginDAO = new LoginDAOImpl();

	@Override
	public boolean verifyLogin(LoginBean bean) {
		return loginDAO.verifyLogin(bean);
	}

	@Override
	public boolean createLogin(LoginBean bean) {
		return loginDAO.createLogin(bean);
	}

	@Override
	public boolean updatePassword(LoginBean bean) {
		return loginDAO.updatePassword(bean);
	}

	@Override
	public boolean deleteLogin(String username) {
		return loginDAO.deleteLogin(username);
	}
}
