package com.wipro.selfPacedDay3.services;

import com.wipro.selfPacedDay3.beans.EmployeeBean;
import com.wipro.selfPacedDay3.daos.EmployeeDAOImpl;
import com.wipro.selfPacedDay3.interfaces.EmployeeDAO;
import com.wipro.selfPacedDay3.interfaces.EmployeeService;

public class EmployeeServiceImpl implements EmployeeService {
	private EmployeeDAO employeeDAO = new EmployeeDAOImpl();

	@Override
	public boolean createEmployee(EmployeeBean bean) {
		return employeeDAO.createEmployee(bean);
	}

	@Override
	public EmployeeBean readEmployee(int employeeNumber) {
		return employeeDAO.readEmployee(employeeNumber);
	}

	@Override
	public boolean updateEmployee(EmployeeBean bean) {
		return employeeDAO.updateEmployee(bean);
	}

	@Override
	public boolean deleteEmployee(int employeeNumber) {
		return employeeDAO.deleteEmployee(employeeNumber);
	}
}
