package com.wipro.selfPacedDay3.beans;

public class EmployeeBean {
	
	// Variables
	
	public int employeeNumber;
	private String name;
	private int salary;
	private String department;
	
	// Constructors
	
	public EmployeeBean() {
		
	}
	
	// Setter methods

	public void setEmployeeNumber(int employeeNumber) {
		this.employeeNumber = employeeNumber;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public void setDepartment(String department) {
		this.department = department;
	}
	
	// Getter methods

	public int getEmployeeNumber() {
		return employeeNumber;
	}

	public String getName() {
		return name;
	}

	public int getSalary() {
		return salary;
	}

	public String getDepartment() {
		return department;
	}
	
}
