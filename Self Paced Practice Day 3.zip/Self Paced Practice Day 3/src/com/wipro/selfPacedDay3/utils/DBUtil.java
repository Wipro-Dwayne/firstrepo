package com.wipro.selfPacedDay3.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {
	static Connection con = null;

	public static Connection getConnection() {
		String url = "jdbc:oracle:thin:@localhost:1522:orcl";
		String uname = "scott";
		String pwd = "tiger";
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection(url, uname, pwd);
			if (con != null) {
				System.out.println("Connected");
			} else {
				System.out.println("Not Connected");
			}
		} catch (SQLException e) {
			System.out.println("Unable to connect to Database due to below errors: \n");
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			System.out.println("Unable to load Database driver, stack trace below: \n");
			e.printStackTrace();
		}
		return con;

	}
}
