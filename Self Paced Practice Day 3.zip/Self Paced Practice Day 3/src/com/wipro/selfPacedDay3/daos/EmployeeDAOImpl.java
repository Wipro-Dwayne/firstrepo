package com.wipro.selfPacedDay3.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.wipro.selfPacedDay3.beans.EmployeeBean;
import com.wipro.selfPacedDay3.interfaces.EmployeeDAO;
import com.wipro.selfPacedDay3.utils.DBUtil;

public class EmployeeDAOImpl implements EmployeeDAO {

	@Override
	public boolean createEmployee(EmployeeBean bean) {
		try{
			Connection con = DBUtil.getConnection();
			String sql = "insert into employee (name, salary, department) values (?, ?, ?)";
			PreparedStatement pst  = con.prepareStatement(sql);
			pst.setString(1, bean.getName());
			pst.setInt(2, bean.getSalary());
			pst.setString(3, bean.getDepartment());
			
			int count=pst.executeUpdate();
			
			if (count==1) {
				return true;
			} else {
				return false;
			}	
		}catch(SQLException e){
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public EmployeeBean readEmployee(int employeeNumber) {
		EmployeeBean bean = null;
		try{
			Connection con = DBUtil.getConnection();
			String sql = "select name, salary, department from employee where employeeid=?";
			PreparedStatement pst  = con.prepareStatement(sql);
			pst.setInt(1, employeeNumber);
			
			ResultSet rs = pst.executeQuery();
			
			if(rs.next()) {
				bean = new EmployeeBean();
				bean.setEmployeeNumber(employeeNumber);
				bean.setName(rs.getString("name"));
				bean.setSalary(rs.getInt("salary"));
				bean.setDepartment(rs.getString("department"));
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
		return bean;
	}

	@Override
	public boolean updateEmployee(EmployeeBean bean) {
		try {
			Connection con = DBUtil.getConnection();
			String sql = "update employee set name=?, salary=?, department=? where employeeid=?";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setString(1, bean.getName());
			pst.setInt(2, bean.getSalary());
			pst.setString(3, bean.getDepartment());
			pst.setInt(4, bean.getEmployeeNumber());
			
			int count=pst.executeUpdate();
			
			if (count==1){
				return true;
			} else {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean deleteEmployee(int employeeNumber) {
		try {
			Connection con = DBUtil.getConnection();
			String sql = "delete from employee where employeeid=?";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setInt(1, employeeNumber);
					
			int count=pst.executeUpdate();
			
			if (count==1)
				return true;
			else
				return false;
			
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
}
