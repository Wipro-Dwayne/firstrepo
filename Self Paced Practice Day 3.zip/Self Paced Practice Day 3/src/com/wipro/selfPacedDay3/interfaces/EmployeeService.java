package com.wipro.selfPacedDay3.interfaces;

import com.wipro.selfPacedDay3.beans.EmployeeBean;

public interface EmployeeService {
	public boolean createEmployee(EmployeeBean bean);
	public EmployeeBean readEmployee(int employeeNumber);
	public boolean updateEmployee(EmployeeBean bean);
	public boolean deleteEmployee(int employeeNumber);
}
