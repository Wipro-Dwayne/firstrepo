package com.wipro.selfPacedDay3.interfaces;

import com.wipro.selfPacedDay3.beans.LoginBean;

public interface LoginService {
	public boolean verifyLogin(LoginBean bean);
	public boolean createLogin(LoginBean bean);
	public boolean updatePassword(LoginBean bean);
	public boolean deleteLogin(String username);
}
